# gemini_handler.py - ChatGPT Integration
import os
import json
from openai import OpenAI
from datetime import datetime

class GeminiHandler:
    def __init__(self):
        self.api_key = os.getenv('OPENAI_API_KEY')
        if self.api_key:
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception as e:
                print(f"Error initializing OpenAI client: {e}")
                self.client = None
        else:
            self.client = None

    def _get_simulated_suggestion(self, context, memory_context=None):
        """Fallback simulated suggestions when API is not available"""
        suggestions = {
            'career': [
                "Consider the long-term growth opportunities in each option.",
                "Reflect on which option aligns with your core values.",
                "Assess the skill development each path offers."
            ],
            'personal': [
                "Listen to your emotional response to each option.",
                "Consider how this decision affects your relationships.",
                "Think about which option brings you more peace."
            ],
            'financial': [
                "Calculate the 5-year ROI for each option.",
                "Consider both risk and potential reward.",
                "Evaluate the impact on your financial stability."
            ]
        }

        # Analyze context for keywords
        context_lower = context.lower()
        if any(word in context_lower for word in ['job', 'career', 'work', 'promotion']):
            category = 'career'
        elif any(word in context_lower for word in ['money', 'invest', 'buy', 'cost']):
            category = 'financial'
        else:
            category = 'personal'

        # Add memory context insights
        memory_insight = ""
        if memory_context:
            memory_insight = " Based on your past decisions, you tend to prioritize long-term stability over immediate gains."

        import random
        suggestion = random.choice(suggestions[category]) + memory_insight

        return {
            'suggestion': suggestion,
            'reasoning': "This suggestion considers your stated goals and decision patterns from your memory history.",
            'confidence': 85,
            'limitations': "AI suggestion based on pattern recognition. Final decision should align with your personal values.",
            'alternative_view': "Consider the opposite perspective for balanced decision making."
        }

    def get_suggestion(self, context, memory_context=None):
        """Get AI suggestion based on context using ChatGPT"""
        try:
            if not self.client:
                # Fallback to simulated responses if no API key
                return self._get_simulated_suggestion(context, memory_context)

            # Prepare the prompt for ChatGPT
            memory_text = ""
            if memory_context:
                memory_text = f"\n\nPast decision patterns: {json.dumps(memory_context)}"

            prompt = f"""You are an AI decision-making assistant. Analyze the following decision context and provide helpful suggestions.

Decision Context: {context}{memory_text}

Please provide:
1. A clear suggestion for the decision
2. Reasoning behind the suggestion
3. Confidence level (0-100)
4. Any limitations or considerations
5. An alternative perspective

Format your response as a JSON object with keys: suggestion, reasoning, confidence, limitations, alternative_view"""

            # Call OpenAI API
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful decision-making assistant that provides thoughtful, balanced advice."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.7
            )

            # Parse the response
            ai_response = response.choices[0].message.content.strip()

            # Try to parse as JSON
            try:
                result = json.loads(ai_response)
                return result
            except json.JSONDecodeError:
                # If not JSON, extract information manually
                return {
                    'suggestion': ai_response.split('\n')[0] if ai_response else "Consider all aspects carefully before deciding.",
                    'reasoning': ai_response,
                    'confidence': 80,
                    'limitations': "AI-generated suggestion based on provided context.",
                    'alternative_view': "Consider consulting with trusted advisors for additional perspectives."
                }

        except Exception as e:
            print(f"Error calling OpenAI API: {e}")
            return self._get_simulated_suggestion(context, memory_context)

    def analyze_patterns(self, decisions):
        """Analyze patterns in past decisions"""
        if not decisions:
            return {"patterns": [], "insights": "No sufficient data for pattern analysis"}

        # Simple pattern detection
        categories = {}
        outcomes = {}

        for decision in decisions:
            cat = decision.get('category', 'uncategorized')
            categories[cat] = categories.get(cat, 0) + 1

            outcome = decision.get('outcome', 'unknown')
            outcomes[outcome] = outcomes.get(outcome, 0) + 1

        insights = []
        if categories:
            most_common = max(categories.items(), key=lambda x: x[1])
            insights.append(f"You make most decisions in the '{most_common[0]}' category")

        if 'positive' in outcomes and outcomes['positive'] > len(decisions) * 0.7:
            insights.append("Your decisions have been mostly positive recently!")

        return {
            'patterns': insights,
            'statistics': {
                'total_decisions': len(decisions),
                'category_distribution': categories,
                'outcome_distribution': outcomes
            }
        }
