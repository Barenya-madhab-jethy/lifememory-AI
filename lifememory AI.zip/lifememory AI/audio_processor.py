# audio_processor.py - Local Audio Processing
import speech_recognition as sr
import pyaudio
import wave
import threading
import queue
import os
from datetime import datetime

class AudioProcessor:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.is_recording = False
        self.audio_queue = queue.Queue()
        
    def speech_to_text(self, audio_path):
        """Convert speech to text using offline model"""
        try:
            with sr.AudioFile(audio_path) as source:
                audio = self.recognizer.record(source)
                # Try different offline recognizers
                try:
                    # Using Sphinx (offline)
                    text = self.recognizer.recognize_sphinx(audio)
                except:
                    # Fallback to basic phoneme recognition
                    text = self._basic_phoneme_recognition(audio_path)
            return text
        except Exception as e:
            print(f"Speech recognition error: {e}")
            return ""
    
    def _basic_phoneme_recognition(self, audio_path):
        """Basic fallback recognition"""
        # This is a simplified version - in production, use proper offline model
        return "[Voice input detected - transcription unavailable in offline mode]"
    
    def start_recording(self, duration=10):
        """Start recording audio"""
        self.is_recording = True
        recording_thread = threading.Thread(target=self._record_audio, args=(duration,))
        recording_thread.start()
        return True
    
    def _record_audio(self, duration):
        """Internal recording function"""
        audio = pyaudio.PyAudio()
        stream = audio.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=16000,
            input=True,
            frames_per_buffer=1024
        )
        
        frames = []
        for _ in range(0, int(16000 / 1024 * duration)):
            if not self.is_recording:
                break
            data = stream.read(1024)
            frames.append(data)
        
        stream.stop_stream()
        stream.close()
        audio.terminate()
        
        # Save to temp file
        filename = f"temp_recording_{datetime.now().timestamp()}.wav"
        self._save_wav(frames, filename)
        self.audio_queue.put(filename)
    
    def stop_recording(self):
        """Stop recording"""
        self.is_recording = False
        try:
            return self.audio_queue.get(timeout=5)
        except queue.Empty:
            return None
    
    def _save_wav(self, frames, filename):
        """Save audio frames to WAV file"""
        wf = wave.open(os.path.join('temp', filename), 'wb')
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(16000)
        wf.writeframes(b''.join(frames))
        wf.close()