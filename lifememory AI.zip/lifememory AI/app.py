from flask import Flask, render_template, request, jsonify, session, send_file
from flask_cors import CORS
import sqlite3
import json
import os
from datetime import datetime
import uuid
from audio_processor import AudioProcessor
from gemini_handler import GeminiHandler
import openai

app = Flask(__name__)
CORS(app)
app.secret_key = 'your-secret-key-here'  # Change this in production

# Initialize processors
audio_processor = AudioProcessor()
gemini_handler = GeminiHandler()

# Database setup
def init_db():
    conn = sqlite3.connect('lifememory.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS decisions
                 (id TEXT PRIMARY KEY, title TEXT, description TEXT, category TEXT,
                  importance INTEGER, created_at TEXT, alternatives TEXT, outcome TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS voice_entries
                 (id TEXT PRIMARY KEY, transcription TEXT, audio_path TEXT, created_at TEXT)''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/timeline')
def timeline():
    return render_template('timeline.html')

@app.route('/voice')
def voice():
    return render_template('voice.html')

@app.route('/reflections')
def reflections():
    return render_template('reflection.html')

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

@app.route('/memory/<decision_id>')
def memory(decision_id):
    return render_template('memory.html')

# API endpoints
@app.route('/api/decisions', methods=['GET', 'POST'])
def handle_decisions():
    if request.method == 'POST':
        data = request.json
        decision_id = str(uuid.uuid4())
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('''INSERT INTO decisions (id, title, description, category, importance, created_at, alternatives)
                     VALUES (?, ?, ?, ?, ?, ?, ?)''',
                  (decision_id, data['title'], data['description'], data.get('category', 'personal'),
                   data['importance'], datetime.now().isoformat(), json.dumps(data.get('alternatives', []))))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'id': decision_id})
    else:
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('SELECT * FROM decisions ORDER BY created_at DESC LIMIT 10')
        decisions = c.fetchall()
        conn.close()
        return jsonify([{'id': d[0], 'title': d[1], 'description': d[2], 'category': d[3],
                        'importance': d[4], 'created_at': d[5], 'alternatives': json.loads(d[6] or '[]'),
                        'outcome': d[7]} for d in decisions])

@app.route('/api/voice/record', methods=['POST'])
def record_voice():
    duration = request.json.get('duration', 10)
    audio_processor.start_recording(duration)
    return jsonify({'success': True})

@app.route('/api/voice/stop', methods=['POST'])
def stop_recording():
    filename = audio_processor.stop_recording()
    if filename:
        transcription = audio_processor.speech_to_text(filename)
        voice_id = str(uuid.uuid4())
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('''INSERT INTO voice_entries (id, transcription, audio_path, created_at)
                     VALUES (?, ?, ?, ?)''',
                  (voice_id, transcription, filename, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'transcription': transcription, 'id': voice_id})
    return jsonify({'success': False})

# AI endpoints
@app.route('/api/ai/suggest', methods=['POST'])
def get_ai_suggestion():
    try:
        data = request.json
        context = data.get('context', '')
        memory_context = data.get('memory_context', [])

        suggestion = gemini_handler.get_suggestion(context, memory_context)
        return jsonify(suggestion)
    except Exception as e:
        print(f"Error getting AI suggestion: {e}")
        return jsonify({
            'suggestion': 'Consider all aspects carefully before making your decision.',
            'reasoning': 'Basic decision-making advice when AI is unavailable.',
            'confidence': 50,
            'limitations': 'AI service temporarily unavailable'
        })

@app.route('/api/reflections', methods=['GET'])
def get_reflections():
    try:
        limit = request.args.get('limit', 10, type=int)
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('SELECT * FROM decisions WHERE outcome IS NOT NULL ORDER BY created_at DESC LIMIT ?',
                  (limit,))
        reflections = c.fetchall()
        conn.close()

        return jsonify([{
            'id': r[0],
            'title': r[1],
            'description': r[2],
            'outcome': r[7],
            'created_at': r[5]
        } for r in reflections])
    except Exception as e:
        print(f"Error getting reflections: {e}")
        return jsonify([])

@app.route('/api/reflections/stats', methods=['GET'])
def get_reflection_stats():
    try:
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('SELECT outcome, COUNT(*) FROM decisions WHERE outcome IS NOT NULL GROUP BY outcome')
        stats = dict(c.fetchall())
        conn.close()

        total_reflections = sum(stats.values())
        positive_outcomes = stats.get('positive', 0) + stats.get('successful', 0)

        return jsonify({
            'total_reflections': total_reflections,
            'positive_rate': (positive_outcomes / total_reflections * 100) if total_reflections > 0 else 0,
            'stats': stats
        })
    except Exception as e:
        print(f"Error getting reflection stats: {e}")
        return jsonify({'total_reflections': 0, 'positive_rate': 0, 'stats': {}})

@app.route('/api/ai/daily-prompt', methods=['GET'])
def get_daily_prompt():
    prompts = [
        "What decision are you most proud of this week and why?",
        "What pattern do you notice in your recent decisions?",
        "How has your decision-making confidence changed recently?",
        "What decision would you make differently if you could go back?",
        "What new information would help you make better decisions?"
    ]
    import random
    return jsonify({'prompt': random.choice(prompts)})

@app.route('/api/ai/reflection-insights', methods=['POST'])
def get_reflection_insights():
    try:
        data = request.json
        reflection_text = data.get('reflection', '')

        # Simple analysis - in production, this would use AI
        insights = {
            'patterns': ['Consistent decision-making approach'],
            'suggestions': ['Continue documenting your decision process'],
            'confidence': 75
        }

        return jsonify(insights)
    except Exception as e:
        print(f"Error getting reflection insights: {e}")
        return jsonify({
            'patterns': [],
            'suggestions': ['Keep reflecting on your decisions'],
            'confidence': 50
        })

@app.route('/api/timeline', methods=['GET'])
def get_timeline():
    try:
        limit = request.args.get('limit', 100, type=int)
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('SELECT * FROM decisions ORDER BY created_at DESC LIMIT ?', (limit,))
        decisions = c.fetchall()
        conn.close()

        return jsonify([{
            'id': d[0],
            'title': d[1],
            'description': d[2],
            'category': d[3],
            'importance': d[4],
            'created_at': d[5],
            'outcome': d[7]
        } for d in decisions])
    except Exception as e:
        print(f"Error getting timeline: {e}")
        return jsonify([])

@app.route('/api/chatbot/chat', methods=['POST'])
def chatbot_chat():
    try:
        data = request.json
        user_message = data.get('message', '')
        conversation_history = data.get('history', [])

        # Get user's decision history for context
        conn = sqlite3.connect('lifememory.db')
        c = conn.cursor()
        c.execute('SELECT * FROM decisions ORDER BY created_at DESC LIMIT 20')
        decisions = c.fetchall()
        conn.close()

        # Prepare context from user's decisions
        decision_context = ""
        if decisions:
            decision_context = "Your past decisions include:\n" + "\n".join([
                f"- {d[1]}: {d[2][:100]}... (Category: {d[3]}, Importance: {d[4]}/5, Outcome: {d[7] or 'pending'})"
                for d in decisions[:10]
            ])

        # Create prompt for AI
        conversation_text = "\n".join([f"User: {msg['user']}\nAssistant: {msg['assistant']}" for msg in conversation_history[-5:]])
        prompt = f"""You are a helpful decision-making assistant for a user who tracks their life decisions.

User's Decision History:
{decision_context}

Conversation History:
{conversation_text}

Current User Message: {user_message}

Please provide helpful advice based on their decision patterns and history. Be conversational, supportive, and reference their past decisions when relevant. Focus on helping them make better decisions in the future."""

        # Check if AI client is available
        if not gemini_handler.client:
            return jsonify({
                'response': "I'm sorry, I'm having trouble connecting right now. Based on your decision history, I recommend considering all options carefully and reflecting on similar past decisions.",
                'success': False
            })

        # Get AI response
        response = gemini_handler.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful decision-making assistant that analyzes user's past decisions to provide personalized advice."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=300,
            temperature=0.7
        )

        ai_response = response.choices[0].message.content.strip()

        return jsonify({
            'response': ai_response,
            'success': True
        })
    except Exception as e:
        print(f"Error in chatbot chat: {e}")
        return jsonify({
            'response': "I'm sorry, I'm having trouble connecting right now. Based on your decision history, I recommend considering all options carefully and reflecting on similar past decisions.",
            'success': False
        })

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
