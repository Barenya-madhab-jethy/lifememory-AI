// Main Application JavaScript
const API_BASE = 'http://127.0.0.1:5000/api';

class LifeMemoryApp {
    constructor() {
        this.currentDecision = null;
        this.voiceRecording = false;
        this.alternativesData = {
            alternatives: [],

            bias_awareness: '',
            risk_tolerance: '',
            time_pressure: ''
        };
        this.init();
    }
    init() {
        this.setupEventListeners();
        this.loadDashboardData();
        this.setupVoiceInput();
    }

    setupEventListeners() {
        // Input mode toggle
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const mode = e.target.dataset.mode;
                this.switchInputMode(mode);
            });
        });

        // New decision sidebar link
        const newDecisionLink = document.querySelector('a[href="#new-decision"]');
        if (newDecisionLink) {
            newDecisionLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.scrollToNewDecision();
            });
        }

        // Voice journal button
        const voiceJournalBtn = document.getElementById('voiceJournalBtn');
        if (voiceJournalBtn) {
            console.log('Voice journal button found, adding event listener');
            voiceJournalBtn.addEventListener('click', (e) => {
                console.log('Voice journal button clicked - preventing default and opening voice journal');
                e.preventDefault();
                e.stopImmediatePropagation();
                this.openVoiceJournal();
                return false;
            });
        } else {
            console.log('Voice journal button not found');
        }

        // Save decision button
        document.getElementById('saveDecisionBtn').addEventListener('click', () => {
            this.showConfirmationModal();
        });

        // Add alternatives button
        document.getElementById('addAlternativesBtn').addEventListener('click', () => {
            this.showAlternativesModal();
        });

        // AI suggestion button
        document.getElementById('getSuggestionBtn').addEventListener('click', () => {
            this.getAISuggestion();
        });

        // Explain suggestion button
        document.getElementById('explainSuggestionBtn').addEventListener('click', () => {
            this.toggleExplanation();
        });

        // Quick actions
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeAllModals();
            });
        });

        // Cancel save button
        document.getElementById('cancelSave').addEventListener('click', () => {
            this.closeAllModals();
        });

        // Confirm save button
        document.getElementById('confirmSave').addEventListener('click', () => {
            this.saveDecision();
        });
    }

    switchInputMode(mode) {
        // Update toggle buttons
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });

        // Show/hide input modes
        document.getElementById('textInputMode').classList.toggle('hidden', mode !== 'text');
        document.getElementById('voiceInputMode').classList.toggle('hidden', mode !== 'voice');
    }

    showConfirmationModal() {
        const title = document.getElementById('decisionTitle').value;
        const description = document.getElementById('decisionDescription').value;

        if (!title.trim()) {
            this.showNotification('Please enter a decision title', 'error');
            return;
        }

        document.getElementById('confirmationModal').classList.remove('hidden');
    }

    showAlternativesModal() {
        const modal = document.getElementById('alternativesModal');
        const modalBody = modal.querySelector('.modal-body');

        modalBody.innerHTML = `
            <div class="alternatives-form">
                <div class="form-group">
                    <label><i class="fas fa-list-ol"></i> Alternatives (List each on new line)</label>
                    <textarea id="alternativesList" rows="5" placeholder="Option 1&#10;Option 2&#10;Option 3"></textarea>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-balance-scale"></i> Pros and Cons</label>
                    <div id="prosConsContainer">
                        <div class="pros-cons-item">
                            <input type="text" placeholder="Option name" class="option-name">
                            <textarea placeholder="Pros (comma separated)"></textarea>
                            <textarea placeholder="Cons (comma separated)"></textarea>
                        </div>
                    </div>
                    <button class="btn-secondary" id="addProsConsRow">+ Add Another Option</button>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-brain"></i> Bias Awareness</label>
                    <select id="biasAwareness">
                        <option value="">Select if applicable</option>
                        <option value="confirmation">Confirmation Bias</option>
                        <option value="anchoring">Anchoring Bias</option>
                        <option value="overconfidence">Overconfidence</option>
                        <option value="sunk_cost">Sunk Cost Fallacy</option>
                        <option value="none">No significant bias detected</option>
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-shield-alt"></i> Risk Tolerance</label>
                    <select id="riskTolerance">
                        <option value="low">Low (Conservative)</option>
                        <option value="medium" selected>Medium (Balanced)</option>
                        <option value="high">High (Aggressive)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-clock"></i> Time Pressure</label>
                    <select id="timePressure">
                        <option value="none">No time pressure</option>
                        <option value="low">Low pressure</option>
                        <option value="medium">Medium pressure</option>
                        <option value="high">High pressure</option>
                        <option value="urgent">Urgent (Immediate)</option>
                    </select>
                </div>

                <div class="form-actions">
                    <button class="btn-primary" id="saveAlternativesBtn">
                        <i class="fas fa-save"></i> Save Alternatives
                    </button>
                </div>
            </div>
        `;

        // Add event listener for new row button
        document.getElementById('addProsConsRow').addEventListener('click', () => {
            this.addProsConsRow();
        });

        // Add event listener for save alternatives button
        document.getElementById('saveAlternativesBtn').addEventListener('click', () => {
            this.saveAlternatives();
        });

        modal.classList.remove('hidden');
    }

    addProsConsRow() {
        const container = document.getElementById('prosConsContainer');
        const newRow = document.createElement('div');
        newRow.className = 'pros-cons-item';
        newRow.innerHTML = `
            <input type="text" placeholder="Option name" class="option-name">
            <textarea placeholder="Pros (comma separated)"></textarea>
            <textarea placeholder="Cons (comma separated)"></textarea>
            <button class="btn-small remove-row">&times;</button>
        `;
        container.appendChild(newRow);

        // Add remove functionality
        newRow.querySelector('.remove-row').addEventListener('click', () => {
            newRow.remove();
        });
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }

    async saveDecision() {
        const decisionData = {
            title: document.getElementById('decisionTitle').value,
            description: document.getElementById('decisionDescription').value,
            intent: document.getElementById('decisionDescription').value.substring(0, 100),
            intent_type: document.getElementById('intentType').value,
            importance: parseInt(document.getElementById('importance').value),
            confidence: 50, // Default confidence
            urgency: 3, // Default urgency
            category: 'uncategorized', // Will be auto-detected later
            tags: [],
            constraints: {},
            emotional_state: '',
            external_pressure: false,
            private_notes: '',
            alternatives: [],
            pros_cons: {},
            final_decision: '',
            reasoning: '',
            bias_awareness: '',
            risk_tolerance: '',
            time_pressure: '',
            decision_maturity: 'initial',
            outcome: 'pending'
        };

        try {
            const response = await fetch(`${API_BASE}/decisions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(decisionData)
            });

            if (response.ok) {
                const result = await response.json();
                this.showNotification('Decision saved successfully!', 'success');
                this.closeAllModals();
                this.clearDecisionForm();
                this.loadRecentDecisions();
                this.updateDashboardStats();
            } else {
                throw new Error('Failed to save decision');
            }
        } catch (error) {
            console.error('Error saving decision:', error);
            this.showNotification('Failed to save decision', 'error');
        }
    }

    clearDecisionForm() {
        document.getElementById('decisionTitle').value = '';
        document.getElementById('decisionDescription').value = '';
    }

    async loadRecentDecisions() {
        try {
            const response = await fetch(`${API_BASE}/decisions?limit=5`);
            const decisions = await response.json();

            const container = document.getElementById('recentDecisions');

            if (decisions.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-clipboard-list"></i>
                        <p>No decisions yet. Create your first one!</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = decisions.map(decision => `
                <div class="decision-item" data-id="${decision.id}">
                    <div class="decision-header">
                        <div>
                            <span class="decision-title">${decision.title}</span>
                            <span class="decision-category">${decision.category || 'uncategorized'}</span>
                        </div>
                        <span class="decision-date">${new Date(decision.created_at).toLocaleDateString()}</span>
                    </div>
                    <p class="decision-description">${decision.description.substring(0, 100)}${decision.description.length > 100 ? '...' : ''}</p>
                    <div class="decision-meta">
                        <span><i class="fas fa-star"></i> Importance: ${decision.importance}/5</span>
                        <span><i class="fas fa-bullseye"></i> Confidence: ${decision.confidence}%</span>
                    </div>
                </div>
            `).join('');

            // Add click events to decision items
            container.querySelectorAll('.decision-item').forEach(item => {
                item.addEventListener('click', (e) => {
                    const decisionId = e.currentTarget.dataset.id;
                    this.viewDecisionDetails(decisionId);
                });
            });

        } catch (error) {
            console.error('Error loading decisions:', error);
        }
    }

    async getAISuggestion() {
        console.log('getAISuggestion called');
        const title = document.getElementById('decisionTitle').value;
        const description = document.getElementById('decisionDescription').value;

        let context = `${title}. ${description}`.trim();
        if (!context) {
            context = "General decision making advice";
        }

        try {
            console.log('Fetching recent decisions...');
            // Get recent decisions for context
            const response = await fetch(`${API_BASE}/decisions?limit=10`);
            const pastDecisions = await response.json();
            console.log('Past decisions fetched:', pastDecisions.length);

            console.log('Fetching AI suggestion...');
            const aiResponse = await fetch(`${API_BASE}/ai/suggest`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    context: context,
                    memory_context: pastDecisions
                })
            });

            console.log('AI response status:', aiResponse.status);
            if (aiResponse.ok) {
                const suggestion = await aiResponse.json();
                console.log('Suggestion received:', suggestion);
                this.displayAISuggestion(suggestion);
            } else {
                console.error('AI response not ok:', aiResponse.status);
                throw new Error('AI response not ok');
            }
        } catch (error) {
            console.error('Error getting AI suggestion:', error);
            this.displayAISuggestion({
                suggestion: "Consider listing all options and weighing their pros and cons systematically.",
                reasoning: "Basic decision-making framework when AI is unavailable.",
                confidence: 60,
                limitations: "Offline mode with limited context"
            });
        }
    }

    displayAISuggestion(suggestion) {
        const aiSuggestion = document.getElementById('aiSuggestion');
        const explanation = document.getElementById('aiExplanation');
        const confidenceMeter = document.querySelector('.meter-fill');
        const confidenceValue = document.querySelector('.confidence-value');

        // Handle both string and object responses
        let suggestionText = suggestion;
        let reasoning = "Analysis based on your decision patterns.";
        let confidence = 75;

        if (typeof suggestion === 'object' && suggestion !== null) {
            suggestionText = suggestion.suggestion || suggestion.message || "Unable to generate suggestion.";
            reasoning = suggestion.reasoning || suggestion.explanation || "AI-powered analysis.";
            confidence = suggestion.confidence || 75;
        }

        aiSuggestion.innerHTML = `<p>${suggestionText}</p>`;

        explanation.querySelector('.explanation-text').textContent = reasoning;

        confidenceMeter.style.width = `${confidence}%`;
        confidenceValue.textContent = `${confidence}%`;

        // Show explanation if it contains additional info
        if (suggestion.limitations || suggestion.alternative_view) {
            explanation.classList.remove('hidden');
        }
    }

    toggleExplanation() {
        const explanation = document.getElementById('aiExplanation');
        explanation.classList.toggle('hidden');
    }

    async updateDashboardStats() {
        try {
            const response = await fetch(`${API_BASE}/decisions`);
            const decisions = await response.json();

            document.getElementById('totalDecisions').textContent = decisions.length;

            // Calculate this month's decisions
            const now = new Date();
            const thisMonth = decisions.filter(d => {
                const decisionDate = new Date(d.created_at);
                return decisionDate.getMonth() === now.getMonth() &&
                    decisionDate.getFullYear() === now.getFullYear();
            }).length;

            document.getElementById('thisMonth').textContent = thisMonth;

            // Calculate average confidence
            const avgConfidence = decisions.length > 0 ?
                Math.round(decisions.reduce((sum, d) => sum + (d.confidence || 50), 0) / decisions.length) :
                0;

            document.getElementById('avgConfidence').textContent = `${avgConfidence}%`;

        } catch (error) {
            console.error('Error updating stats:', error);
        }
    }

    async updateInsights() {
        try {
            const response = await fetch(`${API_BASE}/decisions`);
            const decisions = await response.json();

            if (decisions.length === 0) return;

            // Calculate top category
            const categories = {};
            decisions.forEach(d => {
                const cat = d.category || 'uncategorized';
                categories[cat] = (categories[cat] || 0) + 1;
            });

            const topCategory = Object.entries(categories)
                .sort((a, b) => b[1] - a[1])[0][0];

            document.getElementById('topCategory').textContent = topCategory;

            // Calculate decision trend (last 30 days vs previous 30 days)
            const now = new Date();
            const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

            const recentDecisions = decisions.filter(d => new Date(d.created_at) >= thirtyDaysAgo).length;
            const previousDecisions = decisions.filter(d => {
                const date = new Date(d.created_at);
                return date >= sixtyDaysAgo && date < thirtyDaysAgo;
            }).length;

            let trend = 'Stable';
            if (recentDecisions > previousDecisions + 2) {
                trend = 'Increasing';
            } else if (recentDecisions < previousDecisions - 2) {
                trend = 'Decreasing';
            }

            document.getElementById('decisionTrend').textContent = trend;

            // Simple pattern detection
            const recent = decisions.slice(0, 5);
            const sameCategory = recent.every(d => d.category === recent[0].category);

            if (sameCategory && recent.length >= 3) {
                document.getElementById('patternDetected').textContent =
                    `Focusing on ${recent[0].category}`;
            } else {
                document.getElementById('patternDetected').textContent = 'Diverse decisions';
            }

            // Check for repetition
            const titles = decisions.map(d => d.title.toLowerCase());
            const uniqueTitles = new Set(titles);

            if (titles.length > uniqueTitles.size + 2) {
                document.getElementById('repetitionAlert').textContent = 'Possible repetition';
                document.getElementById('repetitionAlert').style.color = 'var(--warning-color)';
            } else {
                document.getElementById('repetitionAlert').textContent = 'None';
                document.getElementById('repetitionAlert').style.color = '';
            }

        } catch (error) {
            console.error('Error updating insights:', error);
        }
    }

    async loadDashboardData() {
        await Promise.all([
            this.loadRecentDecisions(),
            this.updateDashboardStats(),
            this.updateInsights()
        ]);
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
            <button class="notification-close">&times;</button>
        `;

        // Add to document
        document.body.appendChild(notification);

        // Add styles if not already present
        if (!document.querySelector('#notification-styles')) {
            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    z-index: 10000;
                    animation: slideIn 0.3s ease;
                    max-width: 300px;
                }
                .notification.success {
                    border-left: 4px solid var(--success-color);
                }
                .notification.error {
                    border-left: 4px solid var(--danger-color);
                }
                .notification.warning {
                    border-left: 4px solid var(--warning-color);
                }
                .notification-close {
                    background: none;
                    border: none;
                    font-size: 18px;
                    cursor: pointer;
                    margin-left: auto;
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(styles);
        }

        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);

        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
    }

    handleQuickAction(action) {
        switch (action) {
            case 'reflect':
                window.location.href = '/reflections';
                break;
            case 'search':
                this.showSearchModal();
                break;
            case 'export':
                this.exportData();
                break;
            case 'settings':
                this.showSettings();
                break;
            case 'help':
                this.showHelp();
                break;
            case 'panic':
                this.confirmPanicDelete();
                break;
        }
    }

    confirmPanicDelete() {
        if (confirm('⚠️ PANIC DELETE - This will delete ALL your data permanently. Are you absolutely sure?')) {
            if (confirm('This action cannot be undone. Type "DELETE" to confirm:')) {
                this.panicDelete();
            }
        }
    }

    async panicDelete() {
        try {
            // In a real app, this would call a server endpoint
            // For demo, just clear local display
            this.showNotification('All data deleted (demo mode)', 'warning');

            // Clear display
            document.getElementById('recentDecisions').innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-trash"></i>
                    <p>All data has been deleted</p>
                </div>
            `;

            this.updateDashboardStats();

        } catch (error) {
            console.error('Error deleting data:', error);
            this.showNotification('Error deleting data', 'error');
        }
    }

    viewDecisionDetails(decisionId) {
        // Navigate to decision detail page
        window.location.href = `/memory/${decisionId}`;
    }

    scrollToNewDecision() {
        const newDecisionCard = document.getElementById('newDecisionCard');
        if (newDecisionCard) {
            newDecisionCard.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
            // Focus on the title input
            const titleInput = document.getElementById('decisionTitle');
            if (titleInput) {
                titleInput.focus();
            }
        }
    }

    openVoiceJournal() {
        // Scroll to new decision card
        const newDecisionCard = document.getElementById('newDecisionCard');
        if (newDecisionCard) {
            newDecisionCard.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }

        // Switch to voice input mode
        this.switchInputMode('voice');

        // Focus on the voice recorder
        const recordBtn = document.getElementById('recordBtn');
        if (recordBtn) {
            recordBtn.focus();
        }

        this.showNotification('Voice journal ready - click the microphone to start recording', 'info');
    }

    saveAlternatives() {
        // Collect alternatives from textarea
        const alternativesText = document.getElementById('alternativesList').value;
        const alternatives = alternativesText.split('\n').filter(line => line.trim()).map(line => line.trim());

        // Collect pros and cons
        const prosConsItems = document.querySelectorAll('.pros-cons-item');
        const pros_cons = {};

        prosConsItems.forEach((item, index) => {
            const optionName = item.querySelector('.option-name').value.trim();
            if (optionName) {
                const prosText = item.querySelector('textarea:nth-child(2)').value;
                const consText = item.querySelector('textarea:nth-child(3)').value;

                pros_cons[optionName] = {
                    pros: prosText.split(',').map(p => p.trim()).filter(p => p),
                    cons: consText.split(',').map(c => c.trim()).filter(c => c)
                };
            }
        });

        // Collect other data
        const biasAwareness = document.getElementById('biasAwareness').value;
        const riskTolerance = document.getElementById('riskTolerance').value;
        const timePressure = document.getElementById('timePressure').value;

        // Store in class property
        this.alternativesData = {
            alternatives: alternatives,
            pros_cons: pros_cons,
            bias_awareness: biasAwareness,
            risk_tolerance: riskTolerance,
            time_pressure: timePressure
        };

        // Close modal and show notification
        this.closeAllModals();
        this.showNotification('Alternatives saved successfully!', 'success');
    }

    setupVoiceInput() {
        // Voice recording setup will be in voice.js
        console.log('Voice input setup ready');
    }

    // Missing methods that were moved outside the class
    showSearchModal() {
        // Placeholder for search functionality
        this.showNotification('Search functionality coming soon!', 'info');
    }

    exportData() {
        // Placeholder for export functionality
        this.showNotification('Export functionality coming soon!', 'info');
    }

    showSettings() {
        // Placeholder for settings functionality
        this.showNotification('Settings functionality coming soon!', 'info');
    }

    showHelp() {
        // Placeholder for help functionality
        this.showNotification('Help functionality coming soon!', 'info');
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.app = new LifeMemoryApp();
});