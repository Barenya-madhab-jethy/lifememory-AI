// Timeline visualization functionality
class TimelineViewer {
    constructor() {
        this.events = [];
        this.filteredEvents = [];
        this.currentView = 'timeline';
        this.filters = {
            timeRange: 'all',
            eventTypes: ['decision', 'reflection', 'update', 'outcome'],
            importance: [1, 2, 3, 4, 5],
            customRange: { from: null, to: null }
        };
        this.zoomLevel = 1;
        this.init();
    }

    async init() {
        await this.loadTimelineEvents();
        this.setupEventListeners();
        this.renderTimeline();
        this.updateStatistics();
        this.setupChart();
    }

    async loadTimelineEvents() {
        try {
            const response = await fetch('/api/timeline?limit=100');
            this.events = await response.json();
            this.applyFilters();
        } catch (error) {
            console.error('Error loading timeline events:', error);
            this.showError('Failed to load timeline');
        }
    }

    applyFilters() {
        this.filteredEvents = this.events.filter(event => {
            // Filter by event type
            if (!this.filters.eventTypes.includes(event.event_type)) {
                return false;
            }

            // Filter by time range
            const eventDate = new Date(event.timestamp);
            const now = new Date();

            switch (this.filters.timeRange) {
                case 'today':
                    return eventDate.toDateString() === now.toDateString();
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    return eventDate >= weekAgo;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    return eventDate >= monthAgo;
                case 'year':
                    const yearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
                    return eventDate >= yearAgo;
                case 'custom':
                    if (this.filters.customRange.from && this.filters.customRange.to) {
                        const from = new Date(this.filters.customRange.from);
                        const to = new Date(this.filters.customRange.to);
                        return eventDate >= from && eventDate <= to;
                    }
                    return true;
                default:
                    return true;
            }
        });

        // Sort by date (newest first for timeline view)
        this.filteredEvents.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    }

    renderTimeline() {
        const container = document.querySelector('.timeline');

        if (this.filteredEvents.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>No events found for the selected filters</p>
                </div>
            `;
            return;
        }

        // Group events by date
        const eventsByDate = this.groupEventsByDate(this.filteredEvents);

        container.innerHTML = Object.entries(eventsByDate).map(([date, events]) => `
            <div class="timeline-day">
                <div class="timeline-date">
                    <div class="date-header">
                        <span class="date-day">${new Date(date).getDate()}</span>
                        <span class="date-month">${new Date(date).toLocaleDateString('en-US', { month: 'short' })}</span>
                        <span class="date-year">${new Date(date).getFullYear()}</span>
                    </div>
                </div>
                <div class="timeline-events">
                    ${events.map(event => this.createTimelineEvent(event)).join('')}
                </div>
            </div>
        `).join('');

        // Add event listeners to timeline items
        this.addTimelineEventListeners();
    }

    groupEventsByDate(events) {
        return events.reduce((groups, event) => {
            const date = new Date(event.timestamp).toDateString();
            if (!groups[date]) {
                groups[date] = [];
            }
            groups[date].push(event);
            return groups;
        }, {});
    }

    createTimelineEvent(event) {
            const date = new Date(event.timestamp);
            const time = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const icon = this.getEventIcon(event.event_type);
            const color = this.getEventColor(event.event_type);

            return `
            <div class="timeline-item" data-id="${event.id}" data-type="${event.event_type}">
                <div class="timeline-marker" style="background-color: ${color}">
                    <i class="fas fa-${icon}"></i>
                </div>
                <div class="timeline-content">
                    <div class="timeline-header">
                        <h4>${event.description}</h4>
                        <span class="timeline-time">${time}</span>
                    </div>
                    ${event.decision_title ? `
                        <p class="timeline-context">Decision: ${event.decision_title}</p>
                    ` : ''}
                    <div class="timeline-actions">
                        <button class="btn-small view-event">View Details</button>
                    </div>
                </div>
                <div class="timeline-connector"></div>
            </div>
        `;
    }

    getEventIcon(eventType) {
        const icons = {
            'decision_created': 'plus-circle',
            'decision_updated': 'edit',
            'reflection_added': 'lightbulb',
            'outcome_added': 'flag-checkered',
            'memory_archived': 'archive',
            'memory_deleted': 'trash'
        };
        return icons[eventType] || 'circle';
    }

    getEventColor(eventType) {
        const colors = {
            'decision_created': '#4361ee',
            'decision_updated': '#7209b7',
            'reflection_added': '#4cc9f0',
            'outcome_added': '#f8961e',
            'memory_archived': '#6c757d',
            'memory_deleted': '#f94144'
        };
        return colors[eventType] || '#6c757d';
    }

    addTimelineEventListeners() {
        document.querySelectorAll('.view-event').forEach(button => {
            button.addEventListener('click', (e) => {
                const eventItem = e.target.closest('.timeline-item');
                const eventId = eventItem.dataset.id;
                this.showEventDetails(eventId);
            });
        });

        // Click on timeline item
        document.querySelectorAll('.timeline-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.view-event')) {
                    const eventId = item.dataset.id;
                    this.showEventDetails(eventId);
                }
            });
        });
    }

    async showEventDetails(eventId) {
        try {
            const event = this.events.find(e => e.id === eventId);
            if (!event) return;

            const modal = document.getElementById('eventDetailModal');
            const title = modal.querySelector('#eventTitle');
            const content = modal.querySelector('#eventDetailContent');
            const goToButton = modal.querySelector('#goToEvent');

            title.textContent = event.description;
            
            let eventDetails = `
                <div class="event-detail">
                    <div class="detail-row">
                        <span class="detail-label">Time:</span>
                        <span class="detail-value">${new Date(event.timestamp).toLocaleString()}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Event Type:</span>
                        <span class="detail-value">${event.event_type.replace('_', ' ')}</span>
                    </div>
            `;

            if (event.decision_title) {
                eventDetails += `
                    <div class="detail-row">
                        <span class="detail-label">Decision:</span>
                        <span class="detail-value">${event.decision_title}</span>
                    </div>
                `;
                
                // Set up the "Go to Event" button
                goToButton.onclick = () => {
                    window.location.href = `/memory/${event.decision_id}`;
                };
                goToButton.style.display = 'inline-block';
            } else {
                goToButton.style.display = 'none';
            }

            eventDetails += `</div>`;
            content.innerHTML = eventDetails;

            modal.classList.remove('hidden');
        } catch (error) {
            console.error('Error showing event details:', error);
        }
    }

    renderCalendar() {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        
        document.getElementById('currentMonth').textContent = 
            now.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        
        this.generateCalendarGrid(currentMonth, currentYear);
    }

    generateCalendarGrid(month, year) {
        const container = document.getElementById('calendarGrid');
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        
        // Clear container
        container.innerHTML = '';
        
        // Add day headers
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dayNames.forEach(day => {
            const dayHeader = document.createElement('div');
            dayHeader.className = 'calendar-day-header';
            dayHeader.textContent = day;
            container.appendChild(dayHeader);
        });
        
        // Add empty cells for days before the first day of the month
        const startDay = firstDay.getDay();
        for (let i = 0; i < startDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'calendar-day empty';
            container.appendChild(emptyCell);
        }
        
        // Add days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'calendar-day';
            dayCell.textContent = day;
            
            const dateStr = new Date(year, month, day).toDateString();
            const dayEvents = this.filteredEvents.filter(event => 
                new Date(event.timestamp).toDateString() === dateStr
            );
            
            if (dayEvents.length > 0) {
                dayCell.classList.add('has-events');
                dayCell.title = `${dayEvents.length} events`;
                
                // Add event indicator dots
                const indicators = document.createElement('div');
                indicators.className = 'event-indicators';
                dayEvents.slice(0, 3).forEach(event => {
                    const dot = document.createElement('div');
                    dot.className = 'event-indicator';
                    dot.style.backgroundColor = this.getEventColor(event.event_type);
                    indicators.appendChild(dot);
                });
                dayCell.appendChild(indicators);
            }
            
            // Mark today
            const today = new Date();
            if (day === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                dayCell.classList.add('today');
            }
            
            container.appendChild(dayCell);
        }
    }

    setupChart() {
        const ctx = document.getElementById('timelineChart').getContext('2d');
        
        // Prepare data for chart
        const last30Days = this.getLastNDays(30);
        const decisionCounts = this.calculateDailyCounts('decision_created');
        const reflectionCounts = this.calculateDailyCounts('reflection_added');
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last30Days.map(date => 
                    new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                ),
                datasets: [
                    {
                        label: 'Decisions',
                        data: last30Days.map(date => decisionCounts[date] || 0),
                        borderColor: '#4361ee',
                        backgroundColor: 'rgba(67, 97, 238, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Reflections',
                        data: last30Days.map(date => reflectionCounts[date] || 0),
                        borderColor: '#4cc9f0',
                        backgroundColor: 'rgba(76, 201, 240, 0.1)',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Decision Activity (Last 30 Days)'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }

    getLastNDays(n) {
        const dates = [];
        for (let i = n - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            dates.push(date.toDateString());
        }
        return dates;
    }

    calculateDailyCounts(eventType) {
        const counts = {};
        this.filteredEvents.forEach(event => {
            if (event.event_type === eventType) {
                const date = new Date(event.timestamp).toDateString();
                counts[date] = (counts[date] || 0) + 1;
            }
        });
        return counts;
    }

    setupEventListeners() {
        // View toggle buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const view = e.target.dataset.view;
                this.switchView(view);
            });
        });

        // Filter controls
        document.getElementById('timeRange').addEventListener('change', (e) => {
            this.filters.timeRange = e.target.value;
            this.toggleCustomRange();
            this.applyFilters();
            this.renderCurrentView();
        });

        // Event type checkboxes
        document.querySelectorAll('.checkbox-group input').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateEventTypeFilters();
                this.applyFilters();
                this.renderCurrentView();
            });
        });

        // Importance stars
        document.querySelectorAll('.importance-stars i').forEach(star => {
            star.addEventListener('click', (e) => {
                const value = parseInt(e.target.dataset.value);
                this.toggleImportanceFilter(value);
                this.applyFilters();
                this.renderCurrentView();
            });
        });

        // Filter buttons
        document.getElementById('applyFilters').addEventListener('click', () => {
            this.applyFilters();
            this.renderCurrentView();
            this.updateStatistics();
        });

        document.getElementById('resetFilters').addEventListener('click', () => {
            this.resetFilters();
            this.applyFilters();
            this.renderCurrentView();
            this.updateStatistics();
        });

        // Zoom controls
        document.getElementById('zoomIn').addEventListener('click', () => {
            this.zoomIn();
        });

        document.getElementById('zoomOut').addEventListener('click', () => {
            this.zoomOut();
        });

        // Search
        document.getElementById('timelineSearch').addEventListener('input', (e) => {
            this.searchTimeline(e.target.value);
        });

        // Export and print
        document.getElementById('exportTimeline').addEventListener('click', () => {
            this.exportTimeline();
        });

        document.getElementById('printTimeline').addEventListener('click', () => {
            this.printTimeline();
        });

        // Calendar navigation
        document.getElementById('prevMonth').addEventListener('click', () => {
            this.navigateCalendar(-1);
        });

        document.getElementById('nextMonth').addEventListener('click', () => {
            this.navigateCalendar(1);
        });

        // Graph type selection
        document.getElementById('graphType').addEventListener('change', (e) => {
            this.updateGraphType(e.target.value);
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close, #closeEvent').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.modal').forEach(modal => {
                    modal.classList.add('hidden');
                });
            });
        });
    }

    switchView(view) {
        this.currentView = view;
        
        // Update active button
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
        });
        
        // Show/hide views
        document.querySelectorAll('.timeline-view').forEach(viewEl => {
            viewEl.classList.toggle('hidden', viewEl.id !== `${view}View`);
        });
        
        // Render the selected view
        this.renderCurrentView();
    }

    renderCurrentView() {
        switch (this.currentView) {
            case 'timeline':
                this.renderTimeline();
                break;
            case 'calendar':
                this.renderCalendar();
                break;
            case 'graph':
                this.updateChart();
                break;
        }
    }

    toggleCustomRange() {
        const customRange = document.getElementById('customRange');
        if (this.filters.timeRange === 'custom') {
            customRange.classList.remove('hidden');
        } else {
            customRange.classList.add('hidden');
        }
    }

    updateEventTypeFilters() {
        const checkboxes = document.querySelectorAll('.checkbox-group input:checked');
        this.filters.eventTypes = Array.from(checkboxes).map(cb => cb.value);
    }

    toggleImportanceFilter(value) {
        const index = this.filters.importance.indexOf(value);
        const star = document.querySelector(`.importance-stars i[data-value="${value}"]`);
        
        if (index === -1) {
            this.filters.importance.push(value);
            star.classList.remove('far');
            star.classList.add('fas');
        } else {
            this.filters.importance.splice(index, 1);
            star.classList.remove('fas');
            star.classList.add('far');
        }
    }

    resetFilters() {
        this.filters = {
            timeRange: 'all',
            eventTypes: ['decision', 'reflection', 'update', 'outcome'],
            importance: [1, 2, 3, 4, 5],
            customRange: { from: null, to: null }
        };
        
        // Reset UI elements
        document.getElementById('timeRange').value = 'all';
        document.querySelectorAll('.checkbox-group input').forEach(cb => {
            cb.checked = true;
        });
        document.querySelectorAll('.importance-stars i').forEach((star, i) => {
            star.classList.toggle('fas', i < 5);
            star.classList.toggle('far', i >= 5);
        });
        document.getElementById('customRange').classList.add('hidden');
    }

    zoomIn() {
        if (this.zoomLevel < 2) {
            this.zoomLevel += 0.1;
            this.updateZoom();
        }
    }

    zoomOut() {
        if (this.zoomLevel > 0.5) {
            this.zoomLevel -= 0.1;
            this.updateZoom();
        }
    }

    updateZoom() {
        const timeline = document.querySelector('.timeline-container');
        timeline.style.transform = `scale(${this.zoomLevel})`;
        
        const zoomLevel = document.querySelector('.zoom-level');
        zoomLevel.textContent = `${Math.round(this.zoomLevel * 100)}%`;
    }

    searchTimeline(query) {
        if (!query.trim()) {
            this.renderTimeline();
            return;
        }
        
        const searchResults = this.filteredEvents.filter(event => 
            event.description.toLowerCase().includes(query.toLowerCase()) ||
            (event.decision_title && event.decision_title.toLowerCase().includes(query.toLowerCase()))
        );
        
        this.displaySearchResults(searchResults);
    }

    displaySearchResults(results) {
        const container = document.getElementById('searchResults');
        
        if (results.length === 0) {
            container.innerHTML = '<p class="empty-message">No results found</p>';
            return;
        }
        
        container.innerHTML = results.map(event => `
            <div class="search-result-item" data-id="${event.id}">
                <h5>${event.description}</h5>
                ${event.decision_title ? `<p>Decision: ${event.decision_title}</p>` : ''}
                <p class="result-date">${new Date(event.timestamp).toLocaleString()}</p>
            </div>
        `).join('');
        
        container.classList.remove('hidden');
    }

    updateStatistics() {
        const totalEvents = this.filteredEvents.length;
        const decisions = this.filteredEvents.filter(e => e.event_type.includes('decision')).length;
        const reflections = this.filteredEvents.filter(e => e.event_type.includes('reflection')).length;
        
        document.getElementById('totalEvents').textContent = totalEvents;
        document.getElementById('decisionsCount').textContent = decisions;
        document.getElementById('reflectionsCount').textContent = reflections;
        
        // Calculate growth rate (simplified)
        const growthRate = this.calculateGrowthRate();
        document.getElementById('growthRate').textContent = `${growthRate}%`;
    }

    calculateGrowthRate() {
        // Simplified growth rate calculation
        const now = new Date();
        const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        
        const recentEvents = this.events.filter(e => new Date(e.timestamp) >= lastMonth).length;
        const olderEvents = this.events.filter(e => new Date(e.timestamp) < lastMonth).length;
        
        if (olderEvents === 0) return 100;
        return Math.round(((recentEvents - olderEvents) / olderEvents) * 100);
    }

    updateChart() {
        if (this.chart) {
            this.chart.destroy();
        }
        this.setupChart();
    }

    updateGraphType(type) {
        if (this.chart) {
            this.chart.config.type = type;
            this.chart.update();
        }
    }

    navigateCalendar(direction) {
        // Implementation for calendar navigation
        this.showNotification('Calendar navigation coming soon', 'info');
    }

    exportTimeline() {
        const data = {
            events: this.filteredEvents,
            filters: this.filters,
            exportedAt: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `timeline-export-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showNotification('Timeline exported successfully', 'success');
    }

    printTimeline() {
        window.print();
    }

    showNotification(message, type = 'info') {
        if (window.app && window.app.showNotification) {
            window.app.showNotification(message, type);
        } else {
            alert(message);
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }
}

// Initialize timeline
document.addEventListener('DOMContentLoaded', function() {
    window.timelineViewer = new TimelineViewer();
});