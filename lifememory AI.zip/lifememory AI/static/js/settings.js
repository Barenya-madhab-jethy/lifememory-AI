// Settings page functionality
class SettingsManager {
    constructor() {
        this.settings = {};
        this.unsavedChanges = false;
        this.init();
    }

    async init() {
        await this.loadSettings();
        this.setupEventListeners();
        this.updateSystemInfo();
        this.setupTabs();
    }

    async loadSettings() {
        try {
            const response = await fetch('/api/settings');
            this.settings = await response.json();
            this.applySettingsToUI();
        } catch (error) {
            console.error('Error loading settings:', error);
            this.loadDefaultSettings();
        }
    }

    loadDefaultSettings() {
        this.settings = {
            appearance: {
                darkMode: true,
                theme: 'default',
                fontSize: 'medium',
                density: 'comfortable'
            },
            privacy: {
                offlineMode: true,
                encryptPrivate: true,
                autoDeleteAudio: true,
                panicDeleteEnabled: true
            },
            voice: {
                enabled: true,
                mode: 'push',
                sensitivity: 5,
                recordingLimit: 30
            },
            ai: {
                enabled: true,
                level: 'balanced',
                explanationDepth: 'detailed',
                personality: 'analytical',
                patternSensitivity: 7
            },
            notifications: {
                decisionReminders: true,
                reflectionPrompts: true,
                weeklySummary: true,
                soundEnabled: true
            },
            data: {
                autoBackup: 'weekly',
                exportFormat: 'json',
                autoArchive: 90
            }
        };
    }

    applySettingsToUI() {
        // Appearance
        document.getElementById('darkModeToggle').checked = this.settings.appearance.darkMode;
        document.getElementById('theme').value = this.settings.appearance.theme;
        document.getElementById('fontSize').value = this.settings.appearance.fontSize;
        document.getElementById('density').value = this.settings.appearance.density;

        // Privacy
        document.getElementById('offlineModeToggle').checked = this.settings.privacy.offlineMode;
        document.getElementById('encryptPrivate').checked = this.settings.privacy.encryptPrivate;
        document.getElementById('autoDeleteAudio').checked = this.settings.privacy.autoDeleteAudio;
        document.getElementById('panicDeleteEnabled').checked = this.settings.privacy.panicDeleteEnabled;

        // Voice
        document.getElementById('voiceToggle').checked = this.settings.voice.enabled;
        document.getElementById('voiceMode').value = this.settings.voice.mode;
        document.getElementById('voiceSensitivity').value = this.settings.voice.sensitivity;
        document.getElementById('recordingLimit').value = this.settings.voice.recordingLimit;

        // AI
        document.getElementById('aiToggle').checked = this.settings.ai.enabled;
        document.getElementById('aiLevel').value = this.settings.ai.level;
        document.getElementById('aiExplanation').value = this.settings.ai.explanationDepth;
        document.getElementById('patternSensitivity').value = this.settings.ai.patternSensitivity;

        // Set personality radio
        document.querySelector(`input[name="personality"][value="${this.settings.ai.personality}"]`).checked = true;

        // Data
        document.querySelector(`input[name="backup"][value="${this.settings.data.autoBackup}"]`).checked = true;
        document.getElementById('autoArchive').value = this.settings.data.autoArchive;

        // Update range value displays
        this.updateRangeValue('voiceSensitivity', this.settings.voice.sensitivity);
        this.updateRangeValue('patternSensitivity', this.settings.ai.patternSensitivity);
        this.updateRangeValue('defaultConfidence', 50); // Default value

        // Apply appearance settings
        this.applyAppearanceSettings();
    }

    setupEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.target.closest('.tab-btn').dataset.tab;
                this.switchTab(tab);
            });
        });

        // Quick toggles
        document.getElementById('darkModeToggle').addEventListener('change', (e) => {
            this.toggleDarkMode(e.target.checked);
            this.markUnsaved();
        });

        document.getElementById('offlineModeToggle').addEventListener('change', (e) => {
            this.toggleOfflineMode(e.target.checked);
            this.markUnsaved();
        });

        document.getElementById('voiceToggle').addEventListener('change', (e) => {
            this.toggleVoiceInput(e.target.checked);
            this.markUnsaved();
        });

        document.getElementById('aiToggle').addEventListener('change', (e) => {
            this.toggleAI(e.target.checked);
            this.markUnsaved();
        });

        // Range inputs
        document.querySelectorAll('input[type="range"]').forEach(range => {
            range.addEventListener('input', (e) => {
                this.updateRangeValue(e.target.id, e.target.value);
                this.markUnsaved();
            });
        });

        // Select inputs
        document.querySelectorAll('select').forEach(select => {
            select.addEventListener('change', (e) => {
                this.handleSelectChange(e.target);
                this.markUnsaved();
            });
        });

        // Category management
        document.getElementById('addCategory').addEventListener('click', () => {
            this.addCategory();
        });

        document.querySelectorAll('.category-tag i').forEach(icon => {
            icon.addEventListener('click', (e) => {
                this.removeCategory(e.target.parentElement);
            });
        });

        // Importance stars
        document.querySelectorAll('.importance-select i').forEach(star => {
            star.addEventListener('click', (e) => {
                const value = parseInt(e.target.dataset.value);
                this.setDefaultImportance(value);
                this.markUnsaved();
            });
        });

        // Privacy actions
        document.getElementById('privacyReport').addEventListener('click', () => {
            this.generatePrivacyReport();
        });

        document.getElementById('viewDataMap').addEventListener('click', () => {
            this.viewDataMap();
        });

        document.getElementById('privacyAudit').addEventListener('click', () => {
            this.runPrivacyAudit();
        });

        document.getElementById('deleteAllData').addEventListener('click', () => {
            this.confirmDeleteAllData();
        });

        // Voice test
        document.getElementById('testVoice').addEventListener('click', () => {
            this.testVoiceInput();
        });

        // Data actions
        document.getElementById('exportData').addEventListener('click', () => {
            this.exportAllData();
        });

        document.getElementById('backupNow').addEventListener('click', () => {
            this.createBackup();
        });

        document.getElementById('importData').addEventListener('click', () => {
            this.importData();
        });

        document.getElementById('cleanArchived').addEventListener('click', () => {
            this.cleanArchivedData();
        });

        document.getElementById('cleanOld').addEventListener('click', () => {
            this.cleanOldData();
        });

        document.getElementById('cleanAll').addEventListener('click', () => {
            this.cleanAllData();
        });

        // System actions
        document.getElementById('checkUpdates').addEventListener('click', () => {
            this.checkForUpdates();
        });

        document.getElementById('systemDiagnostics').addEventListener('click', () => {
            this.runDiagnostics();
        });

        document.getElementById('saveSettings').addEventListener('click', () => {
            this.saveAllSettings();
        });

        // Delete confirmation modal
        document.getElementById('confirmDelete').addEventListener('change', (e) => {
            document.getElementById('proceedDelete').disabled = !e.target.checked;
        });

        document.getElementById('cancelDelete').addEventListener('click', () => {
            this.closeDeleteModal();
        });

        document.getElementById('proceedDelete').addEventListener('click', () => {
            this.proceedWithDelete();
        });

        // Warn before leaving with unsaved changes
        window.addEventListener('beforeunload', (e) => {
            if (this.unsavedChanges) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
            }
        });
    }

    setupTabs() {
        // Initialize first tab as active
        this.switchTab('general');
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });

        // Show/hide tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('hidden', content.id !== `${tabName}Tab`);
        });
    }

    toggleDarkMode(enabled) {
        if (enabled) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }

        this.settings.appearance.darkMode = enabled;
        this.showNotification(`Dark mode ${enabled ? 'enabled' : 'disabled'}`, 'success');
    }

    toggleOfflineMode(enabled) {
        this.settings.privacy.offlineMode = enabled;
        this.showNotification(
            `Offline mode ${enabled ? 'enabled. All data stays on your device.' : 'disabled'}`,
            enabled ? 'success' : 'warning'
        );
    }

    toggleVoiceInput(enabled) {
        this.settings.voice.enabled = enabled;
        this.showNotification(
            `Voice input ${enabled ? 'enabled' : 'disabled'}`,
            enabled ? 'success' : 'info'
        );
    }

    toggleAI(enabled) {
        this.settings.ai.enabled = enabled;
        this.showNotification(
            `AI assistant ${enabled ? 'enabled' : 'disabled'}`,
            enabled ? 'success' : 'info'
        );
    }

    handleSelectChange(selectElement) {
        const id = selectElement.id;
        const value = selectElement.value;

        // Update settings based on id
        if (id === 'theme') {
            this.settings.appearance.theme = value;
        } else if (id === 'fontSize') {
            this.settings.appearance.fontSize = value;
        } else if (id === 'density') {
            this.settings.appearance.density = value;
        } else if (id === 'userTimezone') {
            this.settings.general = this.settings.general || {};
            this.settings.general.timezone = value;
        } else if (id === 'decisionCategories') {
            // Handle categories if needed
        } else if (id === 'autoArchive') {
            this.settings.data.autoArchive = parseInt(value);
        } else if (id === 'voiceMode') {
            this.settings.voice.mode = value;
        } else if (id === 'recordingLimit') {
            this.settings.voice.recordingLimit = parseInt(value);
        } else if (id === 'aiLevel') {
            this.settings.ai.level = value;
        } else if (id === 'aiExplanation') {
            this.settings.ai.explanationDepth = value;
        } else if (id === 'cacheSize') {
            this.settings.advanced = this.settings.advanced || {};
            this.settings.advanced.cacheSize = value;
        }

        // Apply appearance settings if changed
        if (['theme', 'fontSize', 'density'].includes(id)) {
            this.applyAppearanceSettings();
        }

        this.markUnsaved();
    }

    applyAppearanceSettings() {
        const { theme, fontSize, density } = this.settings.appearance;

        // Apply theme
        document.body.classList.remove('theme-default', 'theme-dark', 'theme-light');
        document.body.classList.add(`theme-${theme}`);

        // Apply font size
        const fontSizes = { small: '14px', medium: '16px', large: '18px' };
        document.documentElement.style.setProperty('--font-size', fontSizes[fontSize] || '16px');

        // Apply density
        const densities = { comfortable: '8px', compact: '4px' };
        document.documentElement.style.setProperty('--density-padding', densities[density] || '8px');
        document.documentElement.style.setProperty('--density-margin', densities[density] || '8px');

        this.showNotification('Appearance settings applied', 'success');
    }

    updateRangeValue(inputId, value) {
        const range = document.getElementById(inputId);
        const display = range.nextElementSibling;

        if (!display || !display.classList.contains('range-value')) return;

        switch (inputId) {
            case 'voiceSensitivity':
                const sensitivityLabels = ['Very Low', 'Low', 'Medium-Low', 'Medium', 'Medium-High', 'High', 'Very High'];
                display.textContent = sensitivityLabels[Math.floor(value / 1.5)] || 'Medium';
                break;
            case 'patternSensitivity':
                display.textContent = value >= 7 ? 'High' : value >= 4 ? 'Medium' : 'Low';
                break;
            case 'defaultConfidence':
                display.textContent = `${value}%`;
                break;
            case 'playbackSpeed':
                display.textContent = `${(value / 100).toFixed(1)}x`;
                break;
            default:
                display.textContent = value;
        }
    }

    addCategory() {
        const input = document.getElementById('newCategory');
        const value = input.value.trim();

        if (!value) {
            this.showNotification('Please enter a category name', 'warning');
            return;
        }

        const container = document.getElementById('categoriesList');
        const categoryTag = document.createElement('span');
        categoryTag.className = 'category-tag';
        categoryTag.innerHTML = `${value}<i class="fas fa-times"></i>`;

        container.appendChild(categoryTag);
        input.value = '';

        // Add remove listener
        categoryTag.querySelector('i').addEventListener('click', () => {
            this.removeCategory(categoryTag);
        });

        this.markUnsaved();
        this.showNotification(`Category "${value}" added`, 'success');
    }

    removeCategory(tagElement) {
        const category = tagElement.textContent.replace('×', '').trim();
        if (confirm(`Remove category "${category}"?`)) {
            tagElement.remove();
            this.markUnsaved();
            this.showNotification(`Category "${category}" removed`, 'info');
        }
    }

    setDefaultImportance(value) {
        const stars = document.querySelectorAll('.importance-select i');
        stars.forEach((star, index) => {
            if (index < value) {
                star.classList.remove('far');
                star.classList.add('fas');
            } else {
                star.classList.remove('fas');
                star.classList.add('far');
            }
        });

        this.settings.general = this.settings.general || {};
        this.settings.general.defaultImportance = value;
    }

    async generatePrivacyReport() {
        try {
            const response = await fetch('/api/privacy/report');
            const report = await response.json();
            this.displayPrivacyReport(report);
        } catch (error) {
            console.error('Error generating privacy report:', error);
            this.showError('Failed to generate privacy report');
        }
    }

    displayPrivacyReport(report) {
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
            <div class="modal-content wide">
                <div class="modal-header">
                    <h3><i class="fas fa-user-shield"></i> Privacy Report</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="privacy-report">
                        <div class="report-section">
                            <h4>Data Storage</h4>
                            <div class="report-item">
                                <span class="report-label">Location:</span>
                                <span class="report-value">${report.storage.location}</span>
                            </div>
                            <div class="report-item">
                                <span class="report-label">Encryption:</span>
                                <span class="report-value">${report.storage.encryption}</span>
                            </div>
                            <div class="report-item">
                                <span class="report-label">Backup Frequency:</span>
                                <span class="report-value">${report.storage.backup}</span>
                            </div>
                        </div>
                        
                        <div class="report-section">
                            <h4>Permissions</h4>
                            ${report.permissions.map(perm => `
                                <div class="report-item">
                                    <span class="report-label">${perm.name}:</span>
                                    <span class="report-value ${perm.status}">${perm.status}</span>
                                </div>
                            `).join('')}
                        </div>
                        
                        <div class="report-section">
                            <h4>Data Collection</h4>
                            <div class="report-item">
                                <span class="report-label">Voice Recordings:</span>
                                <span class="report-value">${report.dataCollection.voice}</span>
                            </div>
                            <div class="report-item">
                                <span class="report-label">Analytics:</span>
                                <span class="report-value">${report.dataCollection.analytics}</span>
                            </div>
                            <div class="report-item">
                                <span class="report-label">Third-Party Sharing:</span>
                                <span class="report-value">${report.dataCollection.thirdParty}</span>
                            </div>
                        </div>
                        
                        <div class="report-summary">
                            <h4>Privacy Score: ${report.score}/100</h4>
                            <p>${report.summary}</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary close-report">Close</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        modal.classList.remove('hidden');

        // Add close functionality
        const closeBtn = modal.querySelector('.modal-close');
        const closeReportBtn = modal.querySelector('.close-report');
        
        const closeModal = () => {
            modal.remove();
        };
        
        closeBtn.addEventListener('click', closeModal);
        closeReportBtn.addEventListener('click', closeModal);
    }

    viewDataMap() {
        this.showNotification('Data Map visualization coming soon', 'info');
    }

    runPrivacyAudit() {
        this.showNotification('Privacy audit in progress...', 'info');
        
        // Simulate audit process
        setTimeout(() => {
            this.showNotification('Privacy audit completed. No issues found.', 'success');
        }, 2000);
    }

    confirmDeleteAllData() {
        const modal = document.getElementById('deleteConfirmModal');
        document.getElementById('deleteMessage').textContent = 
            'This will permanently delete ALL your data including decisions, reflections, and settings. This action cannot be undone.';
        modal.classList.remove('hidden');
    }

    async testVoiceInput() {
        if (!this.settings.voice.enabled) {
            this.showNotification('Voice input is disabled. Enable it in settings first.', 'warning');
            return;
        }

        const result = document.getElementById('voiceTestResult');
        result.innerHTML = '<i class="fas fa-microphone"></i> Testing microphone...';
        
        try {
            // Test microphone access
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            
            result.innerHTML = '<i class="fas fa-check-circle"></i> Microphone working properly';
            result.className = 'test-result success';
            
            this.showNotification('Voice input test successful', 'success');
        } catch (error) {
            result.innerHTML = '<i class="fas fa-exclamation-circle"></i> Microphone access denied or not available';
            result.className = 'test-result error';
            
            this.showNotification('Microphone test failed. Please check permissions.', 'error');
        }
    }

    async exportAllData() {
        try {
            const response = await fetch('/api/data/export');
            const data = await response.json();
            
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `lifememory-export-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Data exported successfully', 'success');
        } catch (error) {
            console.error('Error exporting data:', error);
            this.showError('Failed to export data');
        }
    }

    async createBackup() {
        try {
            const response = await fetch('/api/backup/create', { method: 'POST' });
            if (response.ok) {
                this.showNotification('Backup created successfully', 'success');
                this.updateSystemInfo();
            }
        } catch (error) {
            console.error('Error creating backup:', error);
            this.showError('Failed to create backup');
        }
    }

    importData() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            if (!confirm('Importing data will replace your current data. Are you sure?')) {
                return;
            }
            
            try {
                const text = await file.text();
                const data = JSON.parse(text);
                
                const response = await fetch('/api/data/import', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                if (response.ok) {
                    this.showNotification('Data imported successfully. Page will reload.', 'success');
                    setTimeout(() => location.reload(), 2000);
                }
            } catch (error) {
                console.error('Error importing data:', error);
                this.showError('Failed to import data. Invalid file format.');
            }
        });
        
        input.click();
    }

    async cleanArchivedData() {
        if (!confirm('Delete all archived memories? This cannot be undone.')) return;
        
        try {
            const response = await fetch('/api/data/clean/archived', { method: 'POST' });
            if (response.ok) {
                this.showNotification('Archived data cleaned', 'success');
                this.updateSystemInfo();
            }
        } catch (error) {
            console.error('Error cleaning archived data:', error);
            this.showError('Failed to clean archived data');
        }
    }

    async cleanOldData() {
        const days = prompt('Delete memories older than how many days?', '365');
        if (!days || isNaN(days)) return;
        
        if (!confirm(`Delete all memories older than ${days} days? This cannot be undone.`)) return;
        
        try {
            const response = await fetch(`/api/data/clean/old/${days}`, { method: 'POST' });
            if (response.ok) {
                this.showNotification(`Data older than ${days} days cleaned`, 'success');
                this.updateSystemInfo();
            }
        } catch (error) {
            console.error('Error cleaning old data:', error);
            this.showError('Failed to clean old data');
        }
    }

    cleanAllData() {
        this.confirmDeleteAllData();
    }

    closeDeleteModal() {
        document.getElementById('deleteConfirmModal').classList.add('hidden');
        document.getElementById('confirmDelete').checked = false;
        document.getElementById('proceedDelete').disabled = true;
    }

    async proceedWithDelete() {
        try {
            const response = await fetch('/api/data/clean/all', { method: 'POST' });
            if (response.ok) {
                this.showNotification('All data deleted successfully', 'success');
                this.closeDeleteModal();
                this.updateSystemInfo();
                
                // Reload page after a delay
                setTimeout(() => location.reload(), 2000);
            }
        } catch (error) {
            console.error('Error deleting all data:', error);
            this.showError('Failed to delete all data');
        }
    }

    checkForUpdates() {
        this.showNotification('Checking for updates...', 'info');
        
        setTimeout(() => {
            this.showNotification('You have the latest version of LifeMemory AI', 'success');
        }, 1500);
    }

    runDiagnostics() {
        this.showNotification('Running system diagnostics...', 'info');
        
        setTimeout(() => {
            const results = {
                database: 'OK',
                storage: 'OK',
                voice: this.settings.voice.enabled ? 'OK' : 'Disabled',
                ai: this.settings.ai.enabled ? 'OK' : 'Disabled',
                privacy: 'Maximum Security'
            };
            
            this.displayDiagnosticResults(results);
        }, 2000);
    }

    displayDiagnosticResults(results) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-stethoscope"></i> System Diagnostics</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="diagnostic-results">
                        ${Object.entries(results).map(([component, status]) => `
                            <div class="diagnostic-item">
                                <span class="component">${component}:</span>
                                <span class="status ${status === 'OK' ? 'success' : 'warning'}">${status}</span>
                            </div>
                        `).join('')}
                    </div>
                    <div class="diagnostic-summary">
                        <p><i class="fas fa-check-circle"></i> All systems operational</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary close-diagnostics">Close</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        modal.classList.remove('hidden');

        // Add close functionality
        modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
        modal.querySelector('.close-diagnostics').addEventListener('click', () => modal.remove());
    }

    async saveAllSettings() {
        try {
            // Gather all settings from UI
            this.gatherSettingsFromUI();
            
            const response = await fetch('/api/settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.settings)
            });
            
            if (response.ok) {
                this.unsavedChanges = false;
                this.showNotification('Settings saved successfully', 'success');
            }
        } catch (error) {
            console.error('Error saving settings:', error);
            this.showError('Failed to save settings');
        }
    }

    gatherSettingsFromUI() {
        // Appearance
        this.settings.appearance.darkMode = document.getElementById('darkModeToggle').checked;
        this.settings.appearance.theme = document.getElementById('theme').value;
        this.settings.appearance.fontSize = document.getElementById('fontSize').value;
        this.settings.appearance.density = document.getElementById('density').value;

        // Privacy
        this.settings.privacy.offlineMode = document.getElementById('offlineModeToggle').checked;
        this.settings.privacy.encryptPrivate = document.getElementById('encryptPrivate').checked;
        this.settings.privacy.autoDeleteAudio = document.getElementById('autoDeleteAudio').checked;
        this.settings.privacy.panicDeleteEnabled = document.getElementById('panicDeleteEnabled').checked;

        // Voice
        this.settings.voice.enabled = document.getElementById('voiceToggle').checked;
        this.settings.voice.mode = document.getElementById('voiceMode').value;
        this.settings.voice.sensitivity = parseInt(document.getElementById('voiceSensitivity').value);
        this.settings.voice.recordingLimit = parseInt(document.getElementById('recordingLimit').value);

        // AI
        this.settings.ai.enabled = document.getElementById('aiToggle').checked;
        this.settings.ai.level = document.getElementById('aiLevel').value;
        this.settings.ai.explanationDepth = document.getElementById('aiExplanation').value;
        this.settings.ai.patternSensitivity = parseInt(document.getElementById('patternSensitivity').value);
        this.settings.ai.personality = document.querySelector('input[name="personality"]:checked').value;

        // Data
        this.settings.data.autoBackup = document.querySelector('input[name="backup"]:checked').value;
        this.settings.data.autoArchive = parseInt(document.getElementById('autoArchive').value);

        // General
        this.settings.general = this.settings.general || {};
        this.settings.general.categories = Array.from(document.querySelectorAll('.category-tag'))
            .map(tag => tag.textContent.replace('×', '').trim());
        this.settings.general.defaultImportance =
            document.querySelectorAll('.importance-select .fas').length;
        this.settings.general.defaultConfidence =
            parseInt(document.getElementById('defaultConfidence').value);
    }

    markUnsaved() {
        this.unsavedChanges = true;
        document.getElementById('saveSettings').classList.add('unsaved');
    }

    async updateSystemInfo() {
        try {
            const response = await fetch('/api/system/info');
            const info = await response.json();
            
            document.getElementById('storageUsage').textContent = info.storage;
            document.getElementById('totalMemories').textContent = info.total_memories || 0;
            document.getElementById('storageUsed').textContent = info.storage_used || '0.5 MB';
            document.getElementById('oldestMemory').textContent = info.oldest_memory || '-';
            document.getElementById('lastBackup').textContent = info.last_backup || 'Never';
        } catch (error) {
            console.error('Error updating system info:', error);
        }
    }

    showNotification(message, type = 'info') {
        if (window.app && window.app.showNotification) {
            window.app.showNotification(message, type);
        } else {
            alert(message);
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }
}

// Initialize settings
document.addEventListener('DOMContentLoaded', function() {
    window.settingsManager = new SettingsManager();
});