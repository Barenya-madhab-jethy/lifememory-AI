// Memory details page functionality
class MemoryDetails {
    constructor(memoryId) {
        this.memoryId = memoryId;
        this.memoryData = null;
        this.init();
    }

    async init() {
        await this.loadMemoryDetails();
        this.setupEventListeners();
        this.updateMemoryStats();
        this.loadRelatedData();
    }

    async loadMemoryDetails() {
        try {
            const response = await fetch(`/api/decisions/${this.memoryId}`);
            this.memoryData = await response.json();
            this.renderMemoryDetails();
        } catch (error) {
            console.error('Error loading memory details:', error);
            this.showError('Failed to load memory details');
        }
    }

    renderMemoryDetails() {
        if (!this.memoryData) return;

        // Update page title
        document.getElementById('memoryTitle').textContent = this.memoryData.title;
        document.title = `${this.memoryData.title} - LifeMemory AI`;

        // Update metadata
        document.getElementById('memoryCreated').textContent =
            new Date(this.memoryData.created_at).toLocaleString();
        document.getElementById('memoryUpdated').textContent =
            new Date(this.memoryData.updated_at).toLocaleString();
        document.getElementById('memoryId').textContent = this.memoryData.id;

        // Update stats
        document.getElementById('importanceValue').textContent = this.memoryData.importance;
        document.getElementById('confidenceValue').textContent = `${this.memoryData.confidence}%`;
        document.getElementById('outcomeValue').textContent = this.memoryData.outcome || 'Pending';

        // Render details
        this.renderDecisionDetails();
        this.renderAlternatives();
        this.renderPrivateNotes();
        this.updateTags();
    }

    renderDecisionDetails() {
        const detailsContainer = document.getElementById('decisionDetails');

        // Intent
        document.getElementById('intentContent').textContent = this.memoryData.intent || 'No intent specified';
        document.getElementById('intentType').textContent = this.memoryData.intent_type || 'Not specified';

        // Constraints
        this.renderConstraints();

        // Emotional state and biases
        document.getElementById('emotionalState').textContent =
            this.memoryData.emotional_state || 'Not specified';
        document.getElementById('biasAwareness').textContent =
            this.memoryData.bias_awareness || 'None detected';
        document.getElementById('externalPressure').textContent =
            this.memoryData.external_pressure ? 'Yes' : 'No';
        document.getElementById('timePressure').textContent =
            this.memoryData.time_pressure || 'Not specified';
        document.getElementById('riskTolerance').textContent =
            this.memoryData.risk_tolerance || 'Medium';
    }

    renderConstraints() {
        const constraints = this.memoryData.constraints || {};
        const container = document.getElementById('constraintsList');

        if (Object.keys(constraints).length === 0) {
            container.innerHTML = '<p class="empty-message">No constraints specified</p>';
            return;
        }

        container.innerHTML = Object.entries(constraints).map(([key, value]) => `
            <div class="constraint-item">
                <span class="constraint-key">${key}:</span>
                <span class="constraint-value">${value}</span>
            </div>
        `).join('');
    }

    renderAlternatives() {
            const alternatives = this.memoryData.alternatives || [];
            const prosCons = this.memoryData.pros_cons || {};
            const container = document.getElementById('alternativesList');

            if (alternatives.length === 0) {
                container.innerHTML = '<p class="empty-message">No alternatives specified</p>';
                return;
            }

            container.innerHTML = alternatives.map((alternative, index) => {
                        const pros = prosCons[alternative] ? .pros || [];
                        const cons = prosCons[alternative] ? .cons || [];

                        return `
                <div class="alternative-item ${alternative === this.memoryData.final_decision ? 'selected' : ''}">
                    <div class="alternative-header">
                        <h4>${alternative}</h4>
                        ${alternative === this.memoryData.final_decision ? 
                            '<span class="selected-badge"><i class="fas fa-check"></i> Selected</span>' : ''}
                    </div>
                    <div class="alternative-analysis">
                        <div class="pros-list">
                            <h5>Pros</h5>
                            ${pros.length > 0 ? 
                                `<ul>${pros.map(pro => `<li>${pro}</li>`).join('')}</ul>` : 
                                '<p class="empty">No pros listed</p>'}
                        </div>
                        <div class="cons-list">
                            <h5>Cons</h5>
                            ${cons.length > 0 ? 
                                `<ul>${cons.map(con => `<li>${con}</li>`).join('')}</ul>` : 
                                '<p class="empty">No cons listed</p>'}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Final decision
        document.getElementById('finalDecision').textContent = 
            this.memoryData.final_decision || 'No final decision recorded';
        document.getElementById('reasoningText').textContent = 
            this.memoryData.reasoning || 'No reasoning provided';
    }

    renderPrivateNotes() {
        const notes = this.memoryData.private_notes;
        const container = document.getElementById('privateNotesContent');
        
        if (!notes || notes.trim() === '') {
            container.innerHTML = '<p class="empty-message">No private notes</p>';
            return;
        }

        container.textContent = notes;
    }

    updateTags() {
        const tags = this.memoryData.tags || [];
        const container = document.getElementById('memoryTags');
        
        if (tags.length === 0) {
            container.innerHTML = '<span class="no-tags">No tags</span>';
            return;
        }

        container.innerHTML = tags.map(tag => 
            `<span class="tag">${tag}</span>`
        ).join('');
    }

    setupEventListeners() {
        // Edit memory button
        document.getElementById('editMemoryBtn').addEventListener('click', () => {
            this.showEditModal();
        });

        // Add reflection button
        document.getElementById('addReflectionBtn').addEventListener('click', () => {
            this.showReflectionModal();
        });

        // Archive button
        document.getElementById('archiveMemoryBtn').addEventListener('click', () => {
            this.archiveMemory();
        });

        // Toggle details
        document.getElementById('toggleDetails').addEventListener('click', (e) => {
            const details = document.getElementById('decisionDetails');
            const icon = e.target.closest('button').querySelector('i');
            
            details.classList.toggle('hidden');
            icon.classList.toggle('fa-chevron-down');
            icon.classList.toggle('fa-chevron-up');
        });

        // Lock notes
        document.getElementById('lockNotes').addEventListener('click', (e) => {
            const icon = e.target.closest('button').querySelector('i');
            const isLocked = icon.classList.contains('fa-eye-slash');
            
            icon.classList.toggle('fa-eye-slash');
            icon.classList.toggle('fa-eye');
            
            if (isLocked) {
                this.showNotification('Notes unlocked', 'success');
            } else {
                this.showNotification('Notes locked', 'info');
            }
        });

        // New reflection button
        document.getElementById('newReflectionBtn').addEventListener('click', () => {
            this.showReflectionModal();
        });

        // Link decision button
        document.getElementById('linkDecisionBtn').addEventListener('click', () => {
            this.showLinkDecisionModal();
        });

        // Refresh AI analysis
        document.getElementById('refreshAnalysis').addEventListener('click', () => {
            this.generateAIAnalysis();
        });

        // Toggle version history
        document.getElementById('toggleHistory').addEventListener('click', (e) => {
            const history = document.getElementById('versionHistory');
            const icon = e.target.closest('button').querySelector('i');
            
            history.classList.toggle('hidden');
            icon.classList.toggle('fa-chevron-down');
            icon.classList.toggle('fa-chevron-up');
        });
    }

    async loadRelatedData() {
        await Promise.all([
            this.loadReflections(),
            this.loadLinkedDecisions(),
            this.loadVersionHistory(),
            this.generateAIAnalysis()
        ]);
    }

    async loadReflections() {
        try {
            const response = await fetch(`/api/reflections?decision_id=${this.memoryId}`);
            const reflections = await response.json();
            this.renderReflections(reflections);
        } catch (error) {
            console.error('Error loading reflections:', error);
        }
    }

    renderReflections(reflections) {
        const container = document.getElementById('reflectionsContainer');
        
        if (reflections.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-lightbulb"></i>
                    <p>No reflections yet. Add one to capture your learnings!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = reflections.map(reflection => `
            <div class="reflection-item" data-id="${reflection.id}">
                <div class="reflection-header">
                    <div class="reflection-type">
                        <i class="fas fa-${this.getReflectionIcon(reflection.reflection_type)}"></i>
                        <span>${this.formatReflectionType(reflection.reflection_type)}</span>
                    </div>
                    <span class="reflection-date">
                        ${new Date(reflection.created_at).toLocaleDateString()}
                    </span>
                </div>
                <div class="reflection-content">
                    <p>${reflection.content}</p>
                </div>
                ${reflection.insights ? `
                    <div class="reflection-insights">
                        <h5>Key Insights:</h5>
                        <p>${reflection.insights}</p>
                    </div>
                ` : ''}
            </div>
        `).join('');
    }

    getReflectionIcon(type) {
        const icons = {
            'outcome': 'flag-checkered',
            'learning': 'graduation-cap',
            'what_if': 'question',
            'growth': 'seedling',
            'regret': 'history'
        };
        return icons[type] || 'lightbulb';
    }

    formatReflectionType(type) {
        const types = {
            'outcome': 'Outcome Analysis',
            'learning': 'Learning Reflection',
            'what_if': 'What-If Analysis',
            'growth': 'Growth Insight',
            'regret': 'Regret Analysis'
        };
        return types[type] || 'Reflection';
    }

    async loadLinkedDecisions() {
        try {
            const linkedIds = this.memoryData.linked_decisions || [];
            const container = document.getElementById('linkedDecisions');
            
            if (linkedIds.length === 0) {
                container.innerHTML = '<p class="empty-message">No linked decisions yet.</p>';
                return;
            }

            // Fetch linked decisions
            const promises = linkedIds.map(id => 
                fetch(`/api/decisions/${id}`).then(r => r.json())
            );
            
            const linkedDecisions = await Promise.all(promises);
            this.renderLinkedDecisions(linkedDecisions);
        } catch (error) {
            console.error('Error loading linked decisions:', error);
        }
    }

    renderLinkedDecisions(decisions) {
        const container = document.getElementById('linkedDecisions');
        
        container.innerHTML = decisions.map(decision => `
            <div class="linked-decision-item" data-id="${decision.id}">
                <div class="linked-decision-header">
                    <h5>${decision.title}</h5>
                    <span class="linked-date">${new Date(decision.created_at).toLocaleDateString()}</span>
                </div>
                <p class="linked-description">${decision.description.substring(0, 100)}...</p>
                <div class="linked-actions">
                    <button class="btn-small view-linked">View</button>
                    <button class="btn-small unlink">Unlink</button>
                </div>
            </div>
        `).join('');
    }

    async loadVersionHistory() {
        try {
            const response = await fetch(`/api/decisions/${this.memoryId}/history`);
            const history = await response.json();
            this.renderVersionHistory(history);
        } catch (error) {
            console.error('Error loading version history:', error);
        }
    }

    renderVersionHistory(history) {
        const container = document.querySelector('#versionHistory .timeline');
        
        if (history.length === 0) {
            container.innerHTML = '<p class="empty-message">No version history available</p>';
            return;
        }

        container.innerHTML = history.map(version => `
            <div class="version-item">
                <div class="version-date">
                    ${new Date(version.timestamp).toLocaleString()}
                </div>
                <div class="version-content">
                    <h5>${version.event_type.replace('_', ' ').toUpperCase()}</h5>
                    <p>${version.description}</p>
                    ${version.changes ? `
                        <div class="version-changes">
                            <h6>Changes:</h6>
                            <pre>${JSON.stringify(version.changes, null, 2)}</pre>
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    async generateAIAnalysis() {
        try {
            // Show loading state
            document.getElementById('patternInsight').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Analyzing patterns...';
            document.getElementById('growthInsight').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Calculating growth...';
            document.getElementById('similarDecisions').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Finding similar decisions...';

            const response = await fetch('/api/ai/analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    decision_id: this.memoryId,
                    context: this.memoryData
                })
            });

            const analysis = await response.json();
            this.renderAIAnalysis(analysis);
        } catch (error) {
            console.error('Error generating AI analysis:', error);
            this.showError('Failed to generate AI analysis');
        }
    }

    renderAIAnalysis(analysis) {
        document.getElementById('patternInsight').textContent = 
            analysis.patterns || 'No significant patterns detected';
        document.getElementById('growthInsight').textContent = 
            analysis.growth_insights || 'Growth analysis unavailable';
        
        this.renderSimilarDecisions(analysis.similar_decisions || []);
    }

    renderSimilarDecisions(decisions) {
        const container = document.getElementById('similarDecisions');
        
        if (decisions.length === 0) {
            container.innerHTML = '<p class="empty-message">No similar decisions found</p>';
            return;
        }

        container.innerHTML = decisions.map(decision => `
            <div class="similar-decision">
                <a href="/memory/${decision.id}" class="similar-link">
                    <i class="fas fa-link"></i>
                    ${decision.title}
                </a>
                <span class="similar-date">${new Date(decision.created_at).toLocaleDateString()}</span>
            </div>
        `).join('');
    }

    showEditModal() {
        const modal = document.getElementById('editMemoryModal');
        const form = modal.querySelector('form');
        
        // Populate form with current data
        form.innerHTML = this.createEditForm();
        
        modal.classList.remove('hidden');
    }

    createEditForm() {
        return `
            <div class="form-group">
                <label for="editTitle">Title</label>
                <input type="text" id="editTitle" value="${this.memoryData.title}">
            </div>
            <div class="form-group">
                <label for="editDescription">Description</label>
                <textarea id="editDescription" rows="4">${this.memoryData.description || ''}</textarea>
            </div>
            <div class="form-group">
                <label for="editCategory">Category</label>
                <input type="text" id="editCategory" value="${this.memoryData.category || ''}">
            </div>
            <div class="form-group">
                <label for="editTags">Tags (comma separated)</label>
                <input type="text" id="editTags" value="${(this.memoryData.tags || []).join(', ')}">
            </div>
            <div class="form-group">
                <label for="editOutcome">Outcome</label>
                <select id="editOutcome">
                    <option value="pending" ${this.memoryData.outcome === 'pending' ? 'selected' : ''}>Pending</option>
                    <option value="positive" ${this.memoryData.outcome === 'positive' ? 'selected' : ''}>Positive</option>
                    <option value="neutral" ${this.memoryData.outcome === 'neutral' ? 'selected' : ''}>Neutral</option>
                    <option value="negative" ${this.memoryData.outcome === 'negative' ? 'selected' : ''}>Negative</option>
                    <option value="mixed" ${this.memoryData.outcome === 'mixed' ? 'selected' : ''}>Mixed</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" id="cancelEdit">Cancel</button>
                <button type="button" class="btn-primary" id="saveEdit">Save Changes</button>
            </div>
        `;
    }

    showReflectionModal() {
        const modal = document.getElementById('reflectionModal');
        modal.classList.remove('hidden');
    }

    showLinkDecisionModal() {
        // Implementation for linking decisions
        this.showNotification('Link decision feature coming soon', 'info');
    }

    async archiveMemory() {
        if (!confirm('Are you sure you want to archive this memory?')) return;

        try {
            const response = await fetch(`/api/decisions/${this.memoryId}/archive`, {
                method: 'POST'
            });

            if (response.ok) {
                this.showNotification('Memory archived successfully', 'success');
                setTimeout(() => {
                    window.location.href = '/';
                }, 1500);
            }
        } catch (error) {
            console.error('Error archiving memory:', error);
            this.showNotification('Failed to archive memory', 'error');
        }
    }

    updateMemoryStats() {
        // Update importance badge color
        const importance = this.memoryData.importance || 3;
        const importanceBadge = document.getElementById('importanceBadge');
        
        importanceBadge.className = 'stat-badge ';
        if (importance >= 4) importanceBadge.classList.add('high');
        else if (importance <= 2) importanceBadge.classList.add('low');
        else importanceBadge.classList.add('medium');

        // Update confidence badge
        const confidence = this.memoryData.confidence || 50;
        const confidenceBadge = document.getElementById('confidenceBadge');
        
        confidenceBadge.className = 'stat-badge ';
        if (confidence >= 70) confidenceBadge.classList.add('high');
        else if (confidence <= 30) confidenceBadge.classList.add('low');
        else confidenceBadge.classList.add('medium');

        // Update outcome badge
        const outcome = this.memoryData.outcome || 'pending';
        const outcomeBadge = document.getElementById('outcomeBadge');
        
        outcomeBadge.className = 'stat-badge ';
        outcomeBadge.classList.add(outcome);
    }

    showNotification(message, type = 'info') {
        // Reuse notification system from main.js
        if (window.app && window.app.showNotification) {
            window.app.showNotification(message, type);
        } else {
            alert(message);
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    const pathSegments = window.location.pathname.split('/');
    const memoryId = pathSegments[pathSegments.length - 1];
    
    if (memoryId && memoryId !== 'memory') {
        window.memoryDetails = new MemoryDetails(memoryId);
    }
});