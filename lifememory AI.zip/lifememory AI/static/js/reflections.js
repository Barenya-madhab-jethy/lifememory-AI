// Reflections tools functionality
class ReflectionTools {
    constructor() {
        this.currentStep = 1;
        this.selectedDecision = null;
        this.reflections = [];
        this.init();
    }

    async init() {
        await this.loadRecentReflections();
        this.setupEventListeners();
        this.updateStats();
        this.loadDailyPrompt();
    }

    async loadRecentReflections() {
        try {
            const response = await fetch('/api/reflections?limit=10');
            this.reflections = await response.json();
            this.renderRecentReflections();
        } catch (error) {
            console.error('Error loading reflections:', error);
            this.showError('Failed to load reflections');
        }
    }

    renderRecentReflections() {
            const container = document.getElementById('recentReflectionsList');

            if (this.reflections.length === 0) {
                container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-lightbulb"></i>
                    <p>No reflections yet. Start your first guided reflection!</p>
                </div>
            `;
                return;
            }

            container.innerHTML = this.reflections.map(reflection => `
            <div class="reflection-summary-item" data-id="${reflection.id}">
                <div class="reflection-header">
                    <div class="reflection-type-badge">
                        <i class="fas fa-${this.getReflectionIcon(reflection.reflection_type)}"></i>
                        <span>${this.formatReflectionType(reflection.reflection_type)}</span>
                    </div>
                    <span class="reflection-date">
                        ${new Date(reflection.created_at).toLocaleDateString()}
                    </span>
                </div>
                <div class="reflection-content-preview">
                    <p>${reflection.content.substring(0, 150)}...</p>
                </div>
                ${reflection.insights ? `
                    <div class="reflection-insights-preview">
                        <strong>Insights:</strong> ${reflection.insights.substring(0, 100)}...
                    </div>
                ` : ''}
                <div class="reflection-actions">
                    <button class="btn-small view-reflection">View</button>
                    <button class="btn-small edit-reflection">Edit</button>
                </div>
            </div>
        `).join('');

        // Add event listeners
        this.addReflectionEventListeners();
    }

    getReflectionIcon(type) {
        const icons = {
            'outcome': 'flag-checkered',
            'learning': 'graduation-cap',
            'what_if': 'question',
            'growth': 'seedling',
            'regret': 'history',
            'quality': 'balance-scale'
        };
        return icons[type] || 'lightbulb';
    }

    formatReflectionType(type) {
        const types = {
            'outcome': 'Outcome Analysis',
            'learning': 'Learning Capture',
            'what_if': 'What-If Analysis',
            'growth': 'Growth Reflection',
            'regret': 'Regret Analysis',
            'quality': 'Quality Review'
        };
        return types[type] || 'Reflection';
    }

    addReflectionEventListeners() {
        // View reflection
        document.querySelectorAll('.view-reflection').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const reflectionId = e.target.closest('.reflection-summary-item').dataset.id;
                this.viewReflection(reflectionId);
            });
        });

        // Edit reflection
        document.querySelectorAll('.edit-reflection').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const reflectionId = e.target.closest('.reflection-summary-item').dataset.id;
                this.editReflection(reflectionId);
            });
        });
    }

    setupEventListeners() {
        // Guided reflection
        document.getElementById('startGuidedReflection').addEventListener('click', () => {
            this.startGuidedReflection();
        });

        document.getElementById('startGuided').addEventListener('click', () => {
            this.startGuidedReflection();
        });

        // What-If simulator
        document.getElementById('startSimulator').addEventListener('click', () => {
            this.startWhatIfSimulator();
        });

        // Pattern analyzer
        document.getElementById('analyzePatternsBtn').addEventListener('click', () => {
            this.analyzePatterns();
        });

        // Growth tracker
        document.getElementById('viewGrowth').addEventListener('click', () => {
            this.viewGrowthReport();
        });

        // New reflection button
        document.getElementById('newReflection').addEventListener('click', () => {
            this.showReflectionModal();
        });

        // Template buttons
        document.querySelectorAll('.template-use').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const template = e.target.dataset.template;
                this.useTemplate(template);
            });
        });

        // Daily prompt
        document.getElementById('usePrompt').addEventListener('click', () => {
            this.useDailyPrompt();
        });

        // AI insights
        document.getElementById('generateInsights').addEventListener('click', () => {
            this.generateAIInsights();
        });

        // Filter by type
        document.querySelectorAll('.type-filter').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const type = e.target.closest('.type-filter').dataset.type;
                this.filterByType(type);
            });
        });

        // Guided reflection modal
        document.getElementById('nextStep').addEventListener('click', () => {
            this.nextGuidedStep();
        });

        document.getElementById('prevStep').addEventListener('click', () => {
            this.prevGuidedStep();
        });

        document.getElementById('finishReflection').addEventListener('click', () => {
            this.finishGuidedReflection();
        });

        // Add learning button
        document.getElementById('addLearning').addEventListener('click', () => {
            this.addLearningField();
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeAllModals();
            });
        });
    }

    async startGuidedReflection() {
        // Load recent decisions for selection
        try {
            const response = await fetch('/api/decisions?limit=20');
            const decisions = await response.json();
            
            const selector = document.getElementById('decisionSelector');
            selector.innerHTML = decisions.map(decision => `
                <div class="decision-option" data-id="${decision.id}">
                    <div class="decision-option-header">
                        <h5>${decision.title}</h5>
                        <span class="decision-date">${new Date(decision.created_at).toLocaleDateString()}</span>
                    </div>
                    <p>${decision.description.substring(0, 100)}...</p>
                    <button class="btn-small select-decision">Select</button>
                </div>
            `).join('');

            // Add selection listeners
            document.querySelectorAll('.select-decision').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const decisionId = e.target.closest('.decision-option').dataset.id;
                    this.selectDecisionForReflection(decisionId);
                });
            });

            // Show modal
            this.currentStep = 1;
            this.updateGuidedStep();
            document.getElementById('guidedReflectionModal').classList.remove('hidden');
        } catch (error) {
            console.error('Error loading decisions:', error);
            this.showError('Failed to load decisions');
        }
    }

    selectDecisionForReflection(decisionId) {
        this.selectedDecision = decisionId;
        this.nextGuidedStep();
    }

    nextGuidedStep() {
        if (this.currentStep < 4) {
            this.currentStep++;
            this.updateGuidedStep();
        }
    }

    prevGuidedStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.updateGuidedStep();
        }
    }

    updateGuidedStep() {
        // Hide all steps
        document.querySelectorAll('.guided-step').forEach(step => {
            step.classList.add('hidden');
        });

        // Show current step
        const currentStep = document.getElementById(`step${this.currentStep}`);
        currentStep.classList.remove('hidden');

        // Update progress bar
        const progress = (this.currentStep / 4) * 100;
        document.querySelector('.progress-fill').style.width = `${progress}%`;
        document.querySelector('.progress-text').textContent = `Step ${this.currentStep} of 4`;

        // Update button visibility
        document.getElementById('prevStep').style.display = this.currentStep > 1 ? 'inline-block' : 'none';
        document.getElementById('nextStep').style.display = this.currentStep < 4 ? 'inline-block' : 'none';
        document.getElementById('finishReflection').style.display = this.currentStep === 4 ? 'inline-block' : 'none';

        // Update summary on final step
        if (this.currentStep === 4) {
            this.updateReflectionSummary();
        }
    }

    updateReflectionSummary() {
        const expected = document.getElementById('expectedOutcome').value;
        const actual = document.getElementById('actualOutcome').value;
        const gap = document.getElementById('gapAnalysis').value;
        const insights = document.getElementById('keyInsights').value;

        const summary = document.getElementById('reflectionSummary');
        summary.innerHTML = `
            <div class="summary-section">
                <h5>Outcome Analysis:</h5>
                <p><strong>Expected:</strong> ${expected || 'Not specified'}</p>
                <p><strong>Actual:</strong> ${actual || 'Not specified'}</p>
                <p><strong>Gap Analysis:</strong> ${gap || 'Not specified'}</p>
            </div>
            <div class="summary-section">
                <h5>Key Insights:</h5>
                <p>${insights || 'No insights recorded'}</p>
            </div>
        `;
    }

    addLearningField() {
        const container = document.querySelector('.learnings-form');
        const newField = document.createElement('div');
        newField.className = 'learning-item';
        newField.innerHTML = `
            <textarea placeholder="Key learning"></textarea>
            <button class="btn-icon remove-learning">&times;</button>
        `;
        container.insertBefore(newField, container.lastElementChild);
        
        // Add remove functionality
        newField.querySelector('.remove-learning').addEventListener('click', () => {
            newField.remove();
        });
    }

    async finishGuidedReflection() {
        // Gather all data
        const reflectionData = {
            decision_id: this.selectedDecision,
            reflection_type: 'learning',
            content: this.compileReflectionContent(),
            insights: document.getElementById('keyInsights').value
        };

        try {
            const response = await fetch('/api/reflections', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(reflectionData)
            });

            if (response.ok) {
                this.showNotification('Reflection saved successfully!', 'success');
                this.closeAllModals();
                this.loadRecentReflections();
                this.updateStats();
            }
        } catch (error) {
            console.error('Error saving reflection:', error);
            this.showError('Failed to save reflection');
        }
    }

    compileReflectionContent() {
        const expected = document.getElementById('expectedOutcome').value;
        const actual = document.getElementById('actualOutcome').value;
        const gap = document.getElementById('gapAnalysis').value;
        
        const learnings = Array.from(document.querySelectorAll('.learning-item textarea'))
            .map(ta => ta.value)
            .filter(text => text.trim() !== '')
            .map((text, i) => `Learning ${i + 1}: ${text}`);
        
        return `
Expected Outcome: ${expected || 'Not specified'}
Actual Outcome: ${actual || 'Not specified'}
Gap Analysis: ${gap || 'Not specified'}
Key Learnings:
${learnings.join('\n')}
        `.trim();
    }

    startWhatIfSimulator() {
        this.showNotification('What-If Simulator coming soon', 'info');
    }

    async analyzePatterns() {
        try {
            const response = await fetch('/api/ai/analyze-patterns');
            const patterns = await response.json();
            this.displayPatternAnalysis(patterns);
        } catch (error) {
            console.error('Error analyzing patterns:', error);
            this.showError('Failed to analyze patterns');
        }
    }

    displayPatternAnalysis(patterns) {
        const container = document.getElementById('patternInsights');
        container.innerHTML = patterns.map(pattern => `
            <div class="pattern-item">
                <i class="fas fa-chart-line"></i>
                <div class="pattern-content">
                    <h5>${pattern.title}</h5>
                    <p>${pattern.description}</p>
                    <div class="pattern-confidence">
                        <span>Confidence: ${pattern.confidence}%</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    viewGrowthReport() {
        this.showNotification('Growth Report coming soon', 'info');
    }

    showReflectionModal() {
        document.getElementById('reflectionModal').classList.remove('hidden');
    }

    useTemplate(template) {
        const templates = {
            'outcome': {
                title: 'Outcome Analysis Template',
                content: 'What was the expected outcome?\nWhat was the actual outcome?\nWhat factors contributed to the difference?\nWhat would you do differently next time?'
            },
            'learning': {
                title: 'Learning Capture Template',
                content: 'What did you learn from this decision?\nHow will this learning affect future decisions?\nWhat insights can you share with others?\nHow can you apply this learning immediately?'
            },
            'whatif': {
                title: 'What-If Analysis Template',
                content: 'What alternative paths were available?\nWhat might have happened with each alternative?\nWhat factors influenced your choice?\nWhat would you choose if you had to decide again?'
            },
            'regret': {
                title: 'Regret Analysis Template',
                content: 'What aspects of the decision do you regret?\nWhat can you learn from this regret?\nHow can you make peace with this decision?\nWhat will you do differently next time?'
            },
            'growth': {
                title: 'Growth Reflection Template',
                content: 'How did this decision help you grow?\nWhat new perspectives did you gain?\nHow has your thinking evolved?\nWhat personal strengths did you discover?'
            },
            'quality': {
                title: 'Decision Quality Review',
                content: 'How thorough was your decision process?\nDid you consider all relevant factors?\nHow could the process be improved?\nWhat decision-making skills did you use?'
            }
        };

        const selected = templates[template];
        if (selected) {
            // Pre-populate the reflection modal
            document.getElementById('reflectionType').value = template;
            document.getElementById('reflectionContent').value = selected.content;
            this.showReflectionModal();
        }
    }

    async loadDailyPrompt() {
        try {
            const response = await fetch('/api/ai/daily-prompt');
            const prompt = await response.json();
            document.getElementById('dailyPrompt').textContent = prompt.text;
        } catch (error) {
            console.error('Error loading daily prompt:', error);
            document.getElementById('dailyPrompt').textContent = 
                'What decision from last month would you make differently today, and why?';
        }
    }

    useDailyPrompt() {
        const prompt = document.getElementById('dailyPrompt').textContent;
        document.getElementById('reflectionContent').value = prompt;
        this.showReflectionModal();
    }

    async generateAIInsights() {
        try {
            // Show loading state
            document.getElementById('patternInsights').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Analyzing reflection patterns...';
            document.getElementById('growthRecommendations').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Generating growth recommendations...';
            document.getElementById('commonThemes').innerHTML = 
                '<i class="fas fa-spinner fa-spin"></i> Identifying common themes...';

            const response = await fetch('/api/ai/reflection-insights', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reflections: this.reflections })
            });

            const insights = await response.json();
            this.displayAIInsights(insights);
        } catch (error) {
            console.error('Error generating AI insights:', error);
            this.showError('Failed to generate AI insights');
        }
    }

    displayAIInsights(insights) {
        document.getElementById('patternInsights').innerHTML = insights.patterns || 
            '<p>No significant patterns detected in your reflections.</p>';
        
        document.getElementById('growthRecommendations').innerHTML = insights.growth_recommendations || 
            '<p>No specific growth recommendations available.</p>';
        
        document.getElementById('commonThemes').innerHTML = insights.common_themes || 
            '<p>No common themes identified yet.</p>';
    }

    filterByType(type) {
        // Update active filter button
        document.querySelectorAll('.type-filter').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.type === type);
        });

        // Filter reflections
        let filtered = this.reflections;
        if (type !== 'all') {
            filtered = this.reflections.filter(r => r.reflection_type === type);
        }

        this.renderFilteredReflections(filtered);
    }

    renderFilteredReflections(reflections) {
        const container = document.getElementById('recentReflectionsList');
        
        if (reflections.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-filter"></i>
                    <p>No reflections of this type found</p>
                </div>
            `;
            return;
        }

        // Reuse the same rendering logic
        container.innerHTML = reflections.map(reflection => `
            <div class="reflection-summary-item" data-id="${reflection.id}">
                <div class="reflection-header">
                    <div class="reflection-type-badge">
                        <i class="fas fa-${this.getReflectionIcon(reflection.reflection_type)}"></i>
                        <span>${this.formatReflectionType(reflection.reflection_type)}</span>
                    </div>
                    <span class="reflection-date">
                        ${new Date(reflection.created_at).toLocaleDateString()}
                    </span>
                </div>
                <div class="reflection-content-preview">
                    <p>${reflection.content.substring(0, 150)}...</p>
                </div>
                ${reflection.insights ? `
                    <div class="reflection-insights-preview">
                        <strong>Insights:</strong> ${reflection.insights.substring(0, 100)}...
                    </div>
                ` : ''}
                <div class="reflection-actions">
                    <button class="btn-small view-reflection">View</button>
                    <button class="btn-small edit-reflection">Edit</button>
                </div>
            </div>
        `).join('');

        this.addReflectionEventListeners();
    }

    async viewReflection(reflectionId) {
        try {
            const response = await fetch(`/api/reflections/${reflectionId}`);
            const reflection = await response.json();
            this.showReflectionDetail(reflection);
        } catch (error) {
            console.error('Error viewing reflection:', error);
            this.showError('Failed to load reflection details');
        }
    }

    showReflectionDetail(reflection) {
        // Create and show a detail modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${this.formatReflectionType(reflection.reflection_type)}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="reflection-detail">
                        <div class="detail-meta">
                            <span class="detail-date">
                                ${new Date(reflection.created_at).toLocaleString()}
                            </span>
                            ${reflection.decision_id ? `
                                <a href="/memory/${reflection.decision_id}" class="detail-decision-link">
                                    <i class="fas fa-link"></i> View Decision
                                </a>
                            ` : ''}
                        </div>
                        <div class="detail-content">
                            <h4>Reflection Content</h4>
                            <p>${reflection.content}</p>
                        </div>
                        ${reflection.insights ? `
                            <div class="detail-insights">
                                <h4>Key Insights</h4>
                                <p>${reflection.insights}</p>
                            </div>
                        ` : ''}
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary close-detail">Close</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        modal.classList.remove('hidden');

        // Add close functionality
        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });
        modal.querySelector('.close-detail').addEventListener('click', () => {
            modal.remove();
        });
    }

    async editReflection(reflectionId) {
        try {
            const response = await fetch(`/api/reflections/${reflectionId}`);
            const reflection = await response.json();
            this.showEditReflectionModal(reflection);
        } catch (error) {
            console.error('Error loading reflection for edit:', error);
            this.showError('Failed to load reflection for editing');
        }
    }

    showEditReflectionModal(reflection) {
        const modal = document.getElementById('reflectionModal');
        
        // Populate form
        document.getElementById('reflectionType').value = reflection.reflection_type;
        document.getElementById('reflectionContent').value = reflection.content;
        document.getElementById('reflectionInsights').value = reflection.insights || '';
        
        // Change button text
        const saveButton = document.getElementById('saveReflection');
        saveButton.textContent = 'Update Reflection';
        saveButton.dataset.id = reflection.id;
        
        modal.classList.remove('hidden');
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
        
        // Reset guided reflection
        this.currentStep = 1;
        this.selectedDecision = null;
        document.getElementById('guidedReflectionModal').classList.add('hidden');
    }

    async updateStats() {
        try {
            const response = await fetch('/api/reflections/stats');
            const stats = await response.json();
            
            document.getElementById('totalReflections').textContent = stats.total || 0;
            document.getElementById('thisWeekReflections').textContent = stats.this_week || 0;
            document.getElementById('avgInsights').textContent = stats.avg_insights || '0';
        } catch (error) {
            console.error('Error updating stats:', error);
        }
    }

    showNotification(message, type = 'info') {
        if (window.app && window.app.showNotification) {
            window.app.showNotification(message, type);
        } else {
            alert(message);
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }
}

// Initialize reflections
document.addEventListener('DOMContentLoaded', function() {
    window.reflectionTools = new ReflectionTools();
});