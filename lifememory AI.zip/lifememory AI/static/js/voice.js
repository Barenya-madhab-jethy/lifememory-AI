// Voice Input Functionality
class VoiceInput {
    constructor() {
        this.isRecording = false;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.recordingTimeout = null;
        this.init();
    }

    init() {
        this.setupVoiceUI();
        this.checkMicrophonePermission();
    }

    setupVoiceUI() {
        const recordBtn = document.getElementById('recordBtn');
        const stopBtn = document.getElementById('stopBtn');
        const voicePreview = document.getElementById('voicePreview');

        if (recordBtn) {
            recordBtn.addEventListener('mousedown', () => this.startRecording());
            recordBtn.addEventListener('mouseup', () => this.stopRecording());
            recordBtn.addEventListener('touchstart', (e) => {
                e.preventDefault();
                this.startRecording();
            });
            recordBtn.addEventListener('touchend', (e) => {
                e.preventDefault();
                this.stopRecording();
            });
        }

        if (stopBtn) {
            stopBtn.addEventListener('click', () => this.stopRecording());
        }
    }

    async checkMicrophonePermission() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            console.log('Microphone permission granted');
        } catch (error) {
            console.warn('Microphone permission denied or not available');
            this.showMicrophoneWarning();
        }
    }

    async startRecording() {
        if (this.isRecording) return;

        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: 16000,
                    channelCount: 1
                }
            });

            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                this.audioChunks.push(event.data);
            };

            this.mediaRecorder.onstop = () => {
                this.processAudio();
            };

            this.mediaRecorder.start();
            this.isRecording = true;

            this.updateUIForRecording(true);
            this.animateVoiceVisualizer(true);

            // Auto-stop recording after 10 seconds
            this.recordingTimeout = setTimeout(() => {
                if (this.isRecording) {
                    this.stopRecording();
                    this.showNotification('Recording stopped after 10 seconds', 'info');
                }
            }, 10000);

        } catch (error) {
            console.error('Error starting recording:', error);
            this.showNotification('Could not access microphone', 'error');
        }
    }

    stopRecording() {
        if (!this.isRecording || !this.mediaRecorder) return;

        // Clear the auto-stop timeout if it exists
        if (this.recordingTimeout) {
            clearTimeout(this.recordingTimeout);
            this.recordingTimeout = null;
        }

        this.mediaRecorder.stop();
        this.isRecording = false;

        // Stop all tracks
        this.mediaRecorder.stream.getTracks().forEach(track => track.stop());

        this.updateUIForRecording(false);
        this.animateVoiceVisualizer(false);
    }

    async processAudio() {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });

        // Show processing indicator
        const preview = document.getElementById('voicePreview');
        preview.innerHTML = '<p><i class="fas fa-spinner fa-spin"></i> Processing audio...</p>';

        try {
            // Convert to text using API
            const text = await this.speechToTextAPI(audioBlob);

            // Update preview
            preview.innerHTML = `
                <p><strong>Transcription:</strong></p>
                <p>${text}</p>
                <div class="voice-actions">
                    <button class="btn-small" id="useTranscription">Use This Text</button>
                    <button class="btn-small secondary" id="retryRecording">Record Again</button>
                </div>
            `;

            // Add event listeners
            document.getElementById('useTranscription').addEventListener('click', () => {
                this.useTranscription(text);
            });

            document.getElementById('retryRecording').addEventListener('click', () => {
                this.startRecording();
            });

        } catch (error) {
            console.error('Error processing audio:', error);
            preview.innerHTML = '<p>Error processing audio. Please try again.</p>';
        }
    }

    async speechToTextAPI(audioBlob) {
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.wav');

        try {
            const response = await fetch('/api/voice/process', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            return result.text || "No speech detected";
        } catch (error) {
            console.error('Error processing audio with API:', error);
            // Fallback to a generic message if API fails
            return "Voice input recorded but transcription failed. Please try again.";
        }
    }

    useTranscription(text) {
        // Populate the text input with transcription
        const description = document.getElementById('decisionDescription');
        if (description) {
            description.value = text;

            // Switch to text mode if in voice mode
            const textModeBtn = document.querySelector('[data-mode="text"]');
            if (!textModeBtn.classList.contains('active')) {
                textModeBtn.click();
            }
        }

        this.showNotification('Voice input added to decision', 'success');
    }

    updateUIForRecording(isRecording) {
        const recordBtn = document.getElementById('recordBtn');
        const stopBtn = document.getElementById('stopBtn');

        if (isRecording) {
            recordBtn.classList.add('hidden');
            stopBtn.classList.remove('hidden');
            recordBtn.innerHTML = '<i class="fas fa-microphone"></i> Recording...';
        } else {
            recordBtn.classList.remove('hidden');
            stopBtn.classList.add('hidden');
            recordBtn.innerHTML = '<i class="fas fa-microphone"></i> Push to Talk';
        }
    }

    animateVoiceVisualizer(start) {
        const visualizer = document.getElementById('voiceVisualizer');
        if (!visualizer) return;

        const bars = visualizer.querySelectorAll('.bar');

        if (start) {
            bars.forEach(bar => {
                bar.style.animation = 'pulse 0.5s infinite alternate';
                bar.style.animationDelay = `${Math.random() * 0.5}s`;
            });
        } else {
            bars.forEach(bar => {
                bar.style.animation = 'none';
                bar.style.height = '5px';
            });
        }
    }

    showMicrophoneWarning() {
        const warning = document.createElement('div');
        warning.className = 'microphone-warning';
        warning.innerHTML = `
            <i class="fas fa-microphone-slash"></i>
            <span>Microphone access is required for voice input. Please enable microphone permissions.</span>
            <button class="warning-close">&times;</button>
        `;

        document.querySelector('.voice-recorder').prepend(warning);

        // Add styles
        const styles = `
            .microphone-warning {
                background: linear-gradient(45deg, var(--warning-color), #ffaa00);
                color: white;
                padding: 10px 15px;
                border-radius: 8px;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 14px;
            }
            .microphone-warning i {
                font-size: 18px;
            }
            .warning-close {
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                cursor: pointer;
                margin-left: auto;
            }
        `;

        if (!document.querySelector('#mic-warning-styles')) {
            const styleEl = document.createElement('style');
            styleEl.id = 'mic-warning-styles';
            styleEl.textContent = styles;
            document.head.appendChild(styleEl);
        }

        // Close button
        warning.querySelector('.warning-close').addEventListener('click', () => {
            warning.remove();
        });
    }

    showNotification(message, type) {
        // Reuse the notification system from main.js
        if (window.app && window.app.showNotification) {
            window.app.showNotification(message, type);
        } else {
            alert(message);
        }
    }
}

// Initialize voice input when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.voiceInput = new VoiceInput();
});