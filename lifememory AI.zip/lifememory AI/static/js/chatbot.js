document.addEventListener('DOMContentLoaded', function() {
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const decisionHistory = document.getElementById('decisionHistory');

    let conversationHistory = [];

    // Load decision history
    loadDecisionHistory();

    // Send message on button click
    sendButton.addEventListener('click', sendMessage);

    // Send message on Enter key
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    async function sendMessage() {
        const message = chatInput.value.trim();
        if (!message) return;

        // Add user message to chat
        addMessage(message, 'user');
        conversationHistory.push({ user: message, assistant: '' });

        // Clear input
        chatInput.value = '';

        // Show typing indicator
        showTypingIndicator();

        try {
            const response = await fetch('/api/chatbot/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    history: conversationHistory.slice(-5) // Send last 5 messages
                })
            });

            const data = await response.json();

            if (data.success) {
                // Update conversation history
                conversationHistory[conversationHistory.length - 1].assistant = data.response;
                addMessage(data.response, 'bot');
            } else {
                addMessage('Sorry, I\'m having trouble connecting right now. Please try again later.', 'bot');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            addMessage('Sorry, there was an error sending your message. Please try again.', 'bot');
        }

        // Hide typing indicator
        hideTypingIndicator();
    }

    function addMessage(content, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        avatarDiv.innerHTML = sender === 'bot' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.innerHTML = `<p>${content.replace(/\n/g, '<br>')}</p>`;

        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);

        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot-message typing';
        typingDiv.id = 'typingIndicator';

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        avatarDiv.innerHTML = '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.innerHTML = '<p><em>Thinking...</em></p>';

        typingDiv.appendChild(avatarDiv);
        typingDiv.appendChild(contentDiv);

        chatMessages.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    async function loadDecisionHistory() {
        try {
            const response = await fetch('/api/decisions?limit=5');
            const decisions = await response.json();

            if (decisions.length > 0) {
                decisionHistory.innerHTML = decisions.map(decision =>
                    `<div class="decision-item">
                        <strong>${decision.title}</strong>
                        <p>${decision.description.substring(0, 100)}...</p>
                        <small>Category: ${decision.category} | Importance: ${decision.importance}/5</small>
                    </div>`
                ).join('');
            } else {
                decisionHistory.innerHTML = '<p>No decisions recorded yet. Start by adding some decisions to get personalized advice!</p>';
            }
        } catch (error) {
            console.error('Error loading decision history:', error);
            decisionHistory.innerHTML = '<p>Error loading decision history.</p>';
        }
    }
});