import requests

# Test the GET /api/decisions endpoint
response = requests.get('http://127.0.0.1:5000/api/decisions')
if response.status_code == 200:
    data = response.json()
    if data:
        decision = data[0]  # Check first decision
        print("Fields in response:", list(decision.keys()))
        print("Total fields:", len(decision))
        print("Missing fields check:")
        required_fields = ['updated_at', 'linked_decisions', 'is_archived', 'is_private']
        for field in required_fields:
            if field in decision:
                print(f"✓ {field}: {decision[field]}")
            else:
                print(f"✗ {field}: MISSING")
    else:
        print("No decisions in database")
else:
    print(f"Error: {response.status_code}")
